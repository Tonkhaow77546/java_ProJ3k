package Homepage;



import Expressed_plan.Account;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import java.awt.image.BufferedImage;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.Dimension;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import out_scource.RoundButton2;

import Taxes.Tax;
import retirement.RetireUI;
import shrot_saving.SaveMoneyUI;
import TimeValue.TimevalueUI;
import Product_installments.InstallmentApp;
import installment.Installment;
import Provident_fund.Provident_fund;
import Expressed_plan.Main_screen;
import Credit_card.CreditCard;
public class HomePage implements ActionListener {
    
    private JFrame frame_1;
    private JFrame frame_0;
    
    private JPanel panel_11;
    private JPanel panel_11_1;
    private JPanel panel_11_2;
    private JPanel panel_11_3;
    private JPanel panel_12;
    private JPanel panel_12_1;
    private JPanel panel_12_2;
    private JPanel panel_12_3;
    private JPanel panel_12_4;
    
    private JPanel panel_13;
    private JPanel panel_14;
    
    private JButton btn_12_1;
    private ImageIcon icon_12_1;
    private JButton btn_12_2;
    private JButton btn_12_3;
    private JButton btn_12_4;
    private JButton btn_12_5;
    private JButton btn_12_6;
    private JButton btn_12_7;
    private JButton btn_12_8;
    private JButton btn_12_9;
    private JButton btn_12_10;
    private JButton btn_12_11;
    
    private JButton btn_11_1;
    private JButton btn_11_2;
    
    private RoundButton2 rbtn_1;
    private RoundButton2 rbtn_2;
    
    private JInternalFrame iframe_1;
    private JDesktopPane desktopPane;
    
    
    
    
    private final JPanel tax_panel = new Tax().getFrame();
    private final JPanel shorterm_panel = new SaveMoneyUI().getFrame();
    private final JPanel retired_panel = new RetireUI().getFrame();
    private final JPanel timevalue_panel = new TimevalueUI().getFrame();
    private final JPanel product_install_panel = new InstallmentApp().getFrame();
    private final JPanel Installment_panel = new Installment().getFrame();
    private final JPanel Provident_panel = new Provident_fund().getFrame();
    private final JPanel Finance_rec_panel = new Main_screen(new Account(true, "kk", 1)).getFrame(); 
    private final JPanel credit_panel = new CreditCard().getFrame();
    private boolean notify_on = false; 
    
    public HomePage(){
        frame_1 = new JFrame("Main");

        panel_11 = new JPanel();
        panel_11.setLayout(new BorderLayout());
        panel_11.setBackground(Color.GRAY);
        panel_11.setBorder(BorderFactory.createLineBorder(Color.GRAY,5));
        
        panel_11_1 = new JPanel();
        panel_11_1.setLayout(new GridLayout(1,1));
        panel_11_1.setBackground(Color.GRAY);
        btn_11_1 = new JButton("Backward");
        btn_11_1.setFont(new Font("Arial", Font.PLAIN, 40));
        panel_11.add(panel_11_1,BorderLayout.WEST);
       
        
        panel_11_3 = new JPanel();
        panel_11_3.setLayout(new FlowLayout());
        panel_11_3.setBackground(Color.GRAY);
        
        
        
        
        rbtn_1 = new RoundButton2(" Notify ");
        panel_11_3.add(rbtn_1);
        rbtn_1.addActionListener(this);
        

        desktopPane = new JDesktopPane();
        iframe_1 = new JInternalFrame("Notification message", false, false, false, true);
        iframe_1.setLayout(new GridLayout(16,1));
        JButton ibtn_1 = new JButton("                                btn_1                                ");
        JButton ibtn_2 = new JButton("                btn_2                ");
        JButton ibtn_3 = new JButton("                btn_3                ");
        iframe_1.add(ibtn_3); iframe_1.add(ibtn_2); iframe_1.add(ibtn_1);

        JButton b2 = new RoundButton2("ProFile");

        panel_11_3.add(b2);
        panel_11.add(panel_11_3,BorderLayout.EAST);
        
        panel_12 = new JPanel();
        panel_12.setLayout(new GridLayout(13,1,5,5));
        panel_12.setBackground(Color.lightGray);
        
        btn_12_1 = new JButton("Tax Calculation");
        btn_12_1.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_1);
        btn_12_1.addActionListener(this);
        
        btn_12_2 = new JButton("Shortterm Saving Plan");
        btn_12_2.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_2);
        btn_12_2.addActionListener(this);
        
        btn_12_3 = new JButton("Retirement Saving Plan");
        btn_12_3.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_3);
        btn_12_3.addActionListener(this);
        
        btn_12_4 = new JButton("Installment Plan");
        btn_12_4.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_4);
        btn_12_4.addActionListener(this);
        
        btn_12_5 = new JButton("Loan Plan");
        btn_12_5.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_5);
        btn_12_5.addActionListener(this);
        
        btn_12_6 = new JButton("Credit Card Plan");
        btn_12_6.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_6);
        btn_12_6.addActionListener(this);
        
        btn_12_7 = new JButton("Value by Time Calculation");
        btn_12_7.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_7);
        btn_12_7.addActionListener(this);
        
        btn_12_8 = new JButton("product intallment plan");
        btn_12_8.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_8);
        btn_12_8.addActionListener(this);
        
        btn_12_9 = new JButton("Provident Fund Plan");
        btn_12_9.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_9);
        btn_12_9.addActionListener(this);
        
        btn_12_10 = new JButton("Expressed Plan");
        btn_12_10.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_10);
        btn_12_10.addActionListener(this);
        
        btn_12_11 = new JButton();
        btn_12_11.setFont(new Font("Arial", Font.PLAIN, 20));
        panel_12.add(btn_12_11);

        JButton addBtn = new JButton();
        panel_12.add(addBtn);
        panel_12.setBorder(BorderFactory.createLineBorder(Color.lightGray,5));

        panel_13 = new JPanel();
        panel_13.setBorder(BorderFactory.createLineBorder(Color.lightGray,5));
        JLabel label_13_1 = new JLabel("Hello!. My name is elon musk.");
        
        panel_13.add(label_13_1);
  
        frame_1.setLayout(new BorderLayout());
        
        frame_1.add(panel_11,BorderLayout.NORTH);
        frame_1.add(panel_12,BorderLayout.WEST);
        frame_1.add(panel_13,BorderLayout.CENTER);
        
        frame_1.setSize(1920,1080);
        frame_1.setMinimumSize(new Dimension(1920, 1080));
        frame_1.setVisible(true);
        frame_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        
    }
    public void playSound(String soundName){
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("mixkit-arcade-game-jump-coin-216.wav").getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex){
          System.out.println("Error with playing sound.");
          ex.printStackTrace( );
        }
    }  

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException{
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");

            //UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
        }
        catch(Exception e){
            e.printStackTrace();
        } 
        HomePage x = new HomePage();  
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object sc = e.getSource();
       // playSound("mixkit-arcade-game-jump-coin-216.wav");
        //Notify
        if(sc.equals(rbtn_1)){
                if (notify_on == false)
                {
                    frame_1.add(iframe_1,BorderLayout.EAST);
                    notify_on = true;
                    iframe_1.setVisible(true);
                    frame_1.setVisible(true);
                }
                else
                {
                    iframe_1.setVisible(false);
                    frame_1.remove(iframe_1);
                    notify_on = false;
                    iframe_1.setVisible(true);
                    frame_1.setVisible(true);
                }
            }
        
        //Backward button
        else if(sc.equals(btn_11_1)){
            panel_11_1.remove(btn_11_1);

                frame_1.remove(panel_13);
                panel_13 = new JPanel();
                JLabel label_13_1 = new JLabel("Hello!. My name is elon musk.");
                panel_13.add(label_13_1);
                frame_1.add(panel_13,BorderLayout.CENTER);
                panel_13.setVisible(true);
                frame_1.setVisible(true);
                frame_1.setSize(1920,1080);
            } 
        
        //taxes
        if(sc.equals(btn_12_1)){
                
                panel_11_1.add(btn_11_1);
                btn_11_1.addActionListener(this);
            
                frame_1.remove(panel_13);
                panel_13.setVisible(false);
                
                panel_13 = new JPanel();
                panel_13.setLayout(new GridLayout(1,1));
                panel_13.add(tax_panel);

                frame_1.add(panel_13,BorderLayout.CENTER);
                
                panel_13.setVisible(true);

                frame_1.setVisible(true);
                frame_1.setSize(1920,1080);
            }
        
        //shorterm
        else if(sc.equals(btn_12_2)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(shorterm_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
            }
        
        //Retirement
        else if(sc.equals(btn_12_3)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(retired_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }
        
        //Installment plan
        else if(sc.equals(btn_12_4)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(Installment_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }

        //Credit Cards plan
        else if(sc.equals(btn_12_6)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(credit_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }
                
        //Value by time 
        else if(sc.equals(btn_12_7)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(timevalue_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }
        
        //product installment 
        else if(sc.equals(btn_12_8)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(product_install_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }
        
        //Expressed plan
        else if(sc.equals(btn_12_10)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(Finance_rec_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }
        //product installment btn_12_10btn_12_10
        else if(sc.equals(btn_12_9)){
            panel_11_1.add(btn_11_1);
            btn_11_1.addActionListener(this);
            
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(1,1));
            panel_13.add(Provident_panel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            frame_1.setSize(1920,1080);
        }
    }
}


