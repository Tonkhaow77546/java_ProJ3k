/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Money_loan;

/**
 *
 * @author TUF GAMING A15
 */
import Homepage.Gframe;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Compound extends JFrame implements ActionListener,Gframe {
    private JFrame frame;
    private JPanel main_pa,input, panelInput, panelBtn, panelResult;
    private JTextField principleField, rateField, paidField, daysField, periodField;
    private JLabel principleLabel, rateLabel, paidLabel, daysLabel, yearsLabel, periodLabel;
    private int principleNum, rateNum, paidNum, daysNum, yearsNum, periodNum;
    private JButton clear, calculate, fixed;
    private JComboBox daysCombo, yearsCombo;
    String[] days = {"28", "29", "30", "31"};
    String[] years = {"365", "366"};
    public Compound(){
        frame = new JFrame("Compound interest");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1080);
        
        main_pa = new JPanel(new BorderLayout());
        main_pa.setSize(1920, 1080);
        
        frame.add(main_pa);
        
        input = new JPanel(new FlowLayout(FlowLayout.CENTER));
        main_pa.add(input, BorderLayout.CENTER);
        
        panelInput = new JPanel(new GridLayout(15,1));
        input.add(panelInput);
 
        principleField = new JTextField("0");
        principleLabel = new JLabel("Principle (Bath)");
        principleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        rateField = new JTextField("0");
        rateLabel = new JLabel("Interest rate (%)");
        rateLabel.setHorizontalAlignment(SwingConstants.LEFT);
        paidField = new JTextField("0");
        paidLabel = new JLabel("The principal has been paid (Bath)");
        paidLabel.setHorizontalAlignment(SwingConstants.LEFT);
        daysField = new JTextField("0");
        daysLabel = new JLabel("Number of days in the month");
        daysLabel.setHorizontalAlignment(SwingConstants.LEFT);
        yearsLabel = new JLabel("Number of days in the year");
        yearsLabel.setHorizontalAlignment(SwingConstants.LEFT);
        calculate = new JButton("Calculate");
        calculate.addActionListener(this);
        clear = new JButton("Clear");
        clear.addActionListener(this);
        
        //setFont
        principleField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        principleField.setPreferredSize(new Dimension(500,30));
        principleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        rateField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        rateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        paidField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        paidLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        daysField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        daysLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        yearsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        calculate.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        clear.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        
        //I want to Create a button but I can't do that bro T-T
        //fixed = new JButton("<- Fixed interest");
        //fixed.addActionListener(this);
        
        daysCombo = new JComboBox(days);
        daysCombo.setSelectedItem("30");
        daysCombo.addActionListener(this);
        yearsCombo = new JComboBox(years);
        yearsCombo.setSelectedItem("365");
        yearsCombo.addActionListener(this);
        
        daysCombo.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        yearsCombo.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        
        periodField  = new JTextField(String.valueOf(periodNum));
        periodField.setEditable(false);
        periodField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        periodLabel = new JLabel("Interest in this period (Bath) ");
        periodLabel.setHorizontalAlignment(0);
        
        periodField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        periodLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        
        panelInput.add(new JPanel());
        panelInput.add(principleLabel);                                   
        panelInput.add(principleField);
        panelInput.add(paidLabel);                                        
        panelInput.add(paidField);
        panelInput.add(rateLabel);                                        
        panelInput.add(rateField);
        panelInput.add(daysLabel);                                        
        panelInput.add(daysCombo);
        panelInput.add(yearsLabel);                                       
        panelInput.add(yearsCombo);
        
        panelInput.add(new JPanel());
        
        panelBtn = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBtn.add(calculate);
        panelBtn.add(clear);
        
        panelInput.add(panelBtn);
        panelInput.add(new JPanel());
        
        panelResult = new JPanel(new GridLayout(1,2));
        panelResult.add(periodLabel);                                     
        panelResult.add(periodField);
        
        panelResult.setVisible(false);
        
        panelInput.add(panelResult);
        
        //frame.setVisible(true);
    }
    public void playSound(String soundName){
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundName).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex){
          System.out.println("Error with playing sound.");
          ex.printStackTrace( );
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        playSound("src/img/mixkit-cool-interface-click-tone-2568.wav");
        JButton button = (JButton) e.getSource();
        if (button.getText().equals("Clear"))
        {   
            panelResult.setVisible(false);
            principleField.setText("0"); 
            rateField.setText("0");
            paidField.setText("0");
            periodField.setText("0");
            daysCombo.setSelectedItem("30");
            yearsCombo.setSelectedItem("365");
        }
        else if (button.getText().equals("Calculate"))
        try {
            principleNum = Integer.parseInt(principleField.getText());
            rateNum = Integer.parseInt(rateField.getText());
            paidNum = Integer.parseInt(paidField.getText());
            comboSelected();
                
            if (principleNum <= 0 || rateNum < 0 || paidNum < 0) {
                throw new IllegalArgumentException("Please enter valid values (greater than 0).");
            }
            
            if (daysCombo.getSelectedItem().equals("28") & yearsCombo.getSelectedItem().equals("366")) {
                throw new IllegalArgumentException("The data is not related.");
            }
            
            if (daysCombo.getSelectedItem().equals("29") & yearsCombo.getSelectedItem().equals("365")) {
                throw new IllegalArgumentException("The data is not related.");
            }
            
            calculate();
            periodField.setText(String.valueOf((int)periodNum));
            panelResult.setVisible(true);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
            principleField.setText("0"); 
            rateField.setText("0");
            paidField.setText("0");
            periodField.setText("0.0");
            daysCombo.setSelectedItem("30");
            yearsCombo.setSelectedItem("365");
            panelResult.setVisible(false);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            principleField.setText("0"); 
            rateField.setText("0");
            paidField.setText("0");
            periodField.setText("0.0");
            daysCombo.setSelectedItem("30");
            yearsCombo.setSelectedItem("365");
            panelResult.setVisible(false);
        }
    }
    
    public void calculate(){
        periodNum = (((((principleNum - paidNum) * (rateNum / 100) * daysNum)) / yearsNum));
    }
    
    public void comboSelected(){
        if (daysCombo.getSelectedItem().equals("28")){
            daysNum = 28;
        }
        if (daysCombo.getSelectedItem().equals("29")){
            daysNum = 29;
        }
        if (daysCombo.getSelectedItem().equals("30")){
            daysNum = 30;
        }
        if (daysCombo.getSelectedItem().equals("31")){
            daysNum = 31;
        }
        
        if (yearsCombo.getSelectedItem().equals("365")){
            yearsNum = 365;
        }
        if (yearsCombo.getSelectedItem().equals("366")){
            yearsNum = 366;
        }
}
    
    /*public static void main(String[] args) {
            new Compound();
        }*/

    @Override
    public JPanel getFrame() {
        return main_pa ;
        }
    }
