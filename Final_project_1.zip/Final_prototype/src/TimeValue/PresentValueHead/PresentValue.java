//Formula calculated by https://www.set.or.th/th/education-research/education/happymoney/glossary/time-value-of-money?lang=th
package TimeValue.PresentValueHead;

import TimeValue.DataInput;

public class PresentValue extends DataInput{
    @Override
    public double calculate(){
        return (getFutureVal()/(Math.pow((1+getReward()), getTime())));
    }
}
