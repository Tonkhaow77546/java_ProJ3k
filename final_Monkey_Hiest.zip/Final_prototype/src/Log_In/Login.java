package Log_In;

import Homepage.HomePage;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.border.Border;

public class Login extends JFrame {

    JLabel usernameLabel, passwordLabel;
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, createbutton;
    
    public void playSound(String soundName){
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundName).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex){
          System.out.println("Error with playing sound.");
          ex.printStackTrace( );
        }}

    public Login() {
        
        
 
        
        setResizable(false);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        usernameLabel = new JLabel("Username:");
        Border bdr = BorderFactory.createLineBorder(Color.BLUE, 2, true);
        usernameLabel.setForeground(new Color(255, 255, 255));
        usernameLabel.setBackground(Color.GRAY);
        usernameLabel.setOpaque(true);
        usernameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(new Color(255, 255, 255));
        passwordLabel.setBackground(Color.GRAY);
        passwordLabel.setOpaque(true);
        passwordLabel.setForeground(new Color(255, 255, 255));
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        createbutton = new JButton("Create Account");
        createbutton.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("src/img/mixkit-cool-interface-click-tone-2568.wav");
                String username = usernameField.getText();
                String password = passwordField.getText();

                try {
                    Register register = new Register();
                    register.createTable();
                    Object[] UserInfo = register.Login(username, password);
                    if (UserInfo[0].equals(true)){
                        JOptionPane.showMessageDialog(Login.this, "Login successful!");
                        dispose();
                        try {
                            new HomePage((AccountDetail)UserInfo[1]);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (InstantiationException ex) {
                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(Login.this, "Invalid username or password.");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Login.this, "Error: " + ex.getMessage());
                }
            }
        });
        
        createbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("src/img/mixkit-cool-interface-click-tone-2568.wav");
                dispose();
                new UserCreation();
            }
        });
        
        JPanel pane_l = new JPanel();
        pane_l.setLayout(new GridLayout(3,1));
        JPanel p1 = new JPanel();

        p1.setLayout(new FlowLayout());
        p1.setBackground(new Color(0,0,0, 0.0f));
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        p2.setBackground(new Color(0,0,0, 0.0f));
        JPanel p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        p3.setBackground(new Color(0,0,0, 0.0f));
        
        p1.add(usernameLabel);
        p1.add(usernameField);
        p2.add(passwordLabel);
        p2.add(passwordField);
        p3.add(loginButton);
        p3.add(createbutton);
        
        pane_l.add(p1);
        pane_l.add(p2);
        pane_l.add(p3);
        
        pane_l.setBackground(new Color(0,0,0, 0.0f));
        try {

        JLabel lbl = new JLabel(new ImageIcon(ImageIO.read(new File("src/Img/KMITL.jpg"))));
        this.setContentPane(lbl);
        lbl.setLayout(new FlowLayout());
        lbl.add(pane_l);
        } catch (IOException e) {};
        setSize(500,300);
        setLocationRelativeTo(null);

        setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Login();
            }
        });
    }
}
