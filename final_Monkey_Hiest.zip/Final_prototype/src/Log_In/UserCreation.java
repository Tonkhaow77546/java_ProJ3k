package Log_In;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.border.Border;

public class UserCreation extends JFrame {
    // MySQL database URL

    JLabel usernameLabel, passwordLabel, nameLabel;
    JTextField usernameField, passwordField, nameField;
    JButton createUserButton;

    public UserCreation() {
        setSize(500, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Border bdr = BorderFactory.createLineBorder(Color.BLUE, 2, true);
        
        usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(new Color(255, 255, 255));
        usernameLabel.setBackground(Color.GRAY);
        usernameLabel.setOpaque(true);
        usernameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(new Color(255, 255, 255));
        passwordLabel.setBackground(Color.GRAY);
        passwordLabel.setOpaque(true);
        passwordLabel.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        nameLabel = new JLabel("Name:");
        nameLabel.setForeground(new Color(255, 255, 255));
        nameLabel.setBackground(Color.GRAY);
        nameLabel.setOpaque(true);
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        nameField = new JTextField(20);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        createUserButton = new JButton("Create User");
        createUserButton.setFont(new Font("Segoe UI", Font.PLAIN, 20));

        createUserButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = passwordField.getText();
                String name = nameField.getText();

                try {
                    Register register = new Register();
                    register.createTable(); //if no table
                    register.createUser(username, password, name);
                    dispose();
                    new Login();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(UserCreation.this, "Error creating user: " + ex.getMessage());
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4,1));
        panel.setBackground(new Color(0,0,0, 0.0f));
        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        p1.setBackground(new Color(0,0,0, 0.0f));
        JPanel p2 = new JPanel();
        p2.setBackground(new Color(0,0,0, 0.0f));
        p2.setLayout(new FlowLayout());
        JPanel p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        p3.setBackground(new Color(0,0,0, 0.0f));
        JPanel p4 = new JPanel();
        p4.setLayout(new FlowLayout());
        p4.setBackground(new Color(0,0,0, 0.0f));
        
        p1.add(usernameLabel);
        p1.add(usernameField);
        p2.add(passwordLabel);
        p2.add(passwordField);
        p3.add(nameLabel);
        p3.add(nameField);
        p4.add(createUserButton);
        
        panel.add(p1);
        panel.add(p2);
        panel.add(p3);
        panel.add(p4);
        //add(panel);
        
         try {

        JLabel lbl = new JLabel(new ImageIcon(ImageIO.read(new File("src/Img/KMITL.jpg"))));
        this.setContentPane(lbl);
        lbl.setLayout(new FlowLayout());
        lbl.add(panel);
        } catch (IOException e) {};
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new UserCreation();
            }
        });
    }
}