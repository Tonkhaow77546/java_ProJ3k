/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Money_loan;

/**
 *
 * @author TUF GAMING A15
 */
import Homepage.Gframe;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Fixed extends JFrame implements ActionListener,Gframe {
    private JFrame frame;
    private JPanel input, dataIn, totalPanel, monthPanel, installPanel, payPanel;
    private JPanel rootPanel;
    private JTextField principleField, rateField, yearsField, totalInterestField, monthInterestField, monthInstallField, monthInstallpayField;
    private JLabel principleLabel, rateLabel, yearsLabel, totalInterestLabel, monthInterestLabel, monthInstallLabel, monthInstallpayLabel;
    private int principleNum, rateNum, yearsNum, totalInterestNum, monthInterestNum, monthInstallNum, monthInstallpayNum;
    private JButton clear, calculate;
    public Fixed(){
        frame = new JFrame("Fixed interest");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1080);
        
        rootPanel = new JPanel(new BorderLayout());
        frame.add(rootPanel);
        input = new JPanel(new FlowLayout(FlowLayout.CENTER));
        rootPanel.add(input, BorderLayout.CENTER);
        
        principleField = new JTextField("0");
        principleField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        principleField.setPreferredSize(new Dimension(500,30));
        principleLabel = new JLabel("Principle (Bath)");
        principleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        principleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        rateField = new JTextField("0");
        rateField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        rateLabel = new JLabel("Interest rate (%)");
        rateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        rateLabel.setHorizontalAlignment(SwingConstants.LEFT);
        yearsField = new JTextField("0");
        yearsField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        yearsLabel = new JLabel("Years");
        yearsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        yearsLabel.setHorizontalAlignment(SwingConstants.LEFT);
        calculate = new JButton("Calculate");
        calculate.addActionListener(this);
        clear = new JButton("Clear");
        clear.addActionListener(this);
        
        //I want to Create a button but I can't do that bro T-T
        //compound = new JButton("Compound interest ->");
        //compound.addActionListener(this);
        
        totalInterestField  = new JTextField(String.valueOf(totalInterestNum));
        totalInterestField.setEditable(false);
        totalInterestField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        totalInterestLabel = new JLabel("Total interest (Bath)");
        totalInterestLabel.setHorizontalAlignment(SwingConstants.LEFT);
        totalInterestLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        monthInterestField  = new JTextField(String.valueOf(monthInterestNum));
        monthInterestField.setEditable(false);
        monthInterestLabel = new JLabel("Interest/Month (Bath)");
        monthInterestField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        monthInterestLabel.setHorizontalAlignment(SwingConstants.LEFT);
        monthInterestLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        monthInstallField  = new JTextField(String.valueOf(monthInstallNum));
        monthInstallField.setEditable(false);
        monthInstallField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        monthInstallLabel = new JLabel("Installment/Month (Bath)");
        monthInstallLabel.setHorizontalAlignment(SwingConstants.LEFT);
        monthInstallLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        monthInstallpayField = new JTextField(String.valueOf(monthInstallpayNum));
        monthInstallpayField.setEditable(false);
        monthInstallpayField.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        monthInstallpayLabel = new JLabel("Installment payment/Month (Bath)");
        monthInstallpayLabel.setHorizontalAlignment(SwingConstants.LEFT);
        monthInstallpayLabel.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        
        dataIn = new JPanel(new GridLayout(13,1));
        
        dataIn.add(principleLabel);                                   
        dataIn.add(principleField);
        dataIn.add(rateLabel);                                        
        dataIn.add(rateField);
        dataIn.add(yearsLabel);                                       
        dataIn.add(yearsField);
        dataIn.add(new JPanel());
        
        JPanel btnPanel = new JPanel();
        clear.setPreferredSize(new Dimension(150,30));
        calculate.setPreferredSize(new Dimension(150,30));
        clear.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        calculate.setFont(new Font("Segoe UI", Font.PLAIN, 24));
        btnPanel.add(calculate);
        btnPanel.add(clear);         
        
        
        dataIn.add(btnPanel);
        dataIn.add(new JPanel());
        
        input.add(dataIn);
        
        totalPanel = new JPanel(new GridLayout(1,2));
        totalPanel.add(totalInterestLabel);
        totalPanel.add(totalInterestField);
        dataIn.add(totalPanel);
        
        monthPanel = new JPanel(new GridLayout(1,2));
        monthPanel.add(monthInterestLabel);
        monthPanel.add(monthInterestField);
        dataIn.add(monthPanel);
        
        installPanel = new JPanel(new GridLayout(1,2));
        installPanel.add(monthInstallLabel);
        installPanel.add(monthInstallField);
        dataIn.add(installPanel);
        
        payPanel = new JPanel(new GridLayout(1,2));
        payPanel.add(monthInstallpayLabel);
        payPanel.add(monthInstallpayField);
        dataIn.add(payPanel);
        
        totalInterestField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        monthInterestField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        monthInstallField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        monthInstallpayField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        
        totalPanel.setVisible(false);
        monthPanel.setVisible(false);
        installPanel.setVisible(false);
        payPanel.setVisible(false);

        //frame.setVisible(true);
    }
    
    public void playSound(String soundName){
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundName).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex){
          System.out.println("Error with playing sound.");
          ex.printStackTrace( );
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        playSound("src/img/mixkit-cool-interface-click-tone-2568.wav");
        JButton button = (JButton) e.getSource();
        if (button.getText().equals("Clear"))
        {
            principleField.setText("0"); 
            rateField.setText("0");
            yearsField.setText("0");
            totalInterestField.setText("0");
            monthInterestField.setText("0");
            monthInstallField.setText("0");
            monthInstallpayField.setText("0");
            totalPanel.setVisible(false);
            monthPanel.setVisible(false);
            installPanel.setVisible(false);
            payPanel.setVisible(false);
        }
        else if (button.getText().equals("Calculate"))
        try {
            principleNum = Integer.parseInt(principleField.getText());
            rateNum = Integer.parseInt(rateField.getText());
            yearsNum = Integer.parseInt(yearsField.getText());
                
            if (principleNum <= 0 || rateNum < 0 || yearsNum < 0) {
                throw new IllegalArgumentException("Please enter valid values (greater than 0).");
            }

            calculate();
            totalInterestField.setText(String.valueOf((int)totalInterestNum));
            monthInterestField.setText(String.valueOf((int)monthInterestNum));
            monthInstallField.setText(String.valueOf((int)monthInstallNum));
            monthInstallpayField.setText(String.valueOf((int)monthInstallpayNum));
            totalPanel.setVisible(true);
            monthPanel.setVisible(true);
            installPanel.setVisible(true);
            payPanel.setVisible(true);
                
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
            principleField.setText("0"); 
            rateField.setText("0");
            yearsField.setText("0");
            totalInterestField.setText("0");
            monthInterestField.setText("0");
            monthInstallField.setText("0");
            monthInstallpayField.setText("0");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            principleField.setText("0"); 
            rateField.setText("0");
            yearsField.setText("0");
            totalInterestField.setText("0");
            monthInterestField.setText("0");
            monthInstallField.setText("0");
            monthInstallpayField.setText("0");
        }
    }
    
    public void calculate(){
        totalInterestNum = (principleNum * (rateNum / 100) * yearsNum);
        monthInterestNum = ((principleNum * (rateNum / 100) * yearsNum) / (yearsNum * 12));
        monthInstallNum = (principleNum / (yearsNum * 12));
        monthInstallpayNum = (((principleNum + (principleNum * (rateNum / 100) * yearsNum))) / (yearsNum * 12));
    }
    
   /* public static void main(String[] args) {
            new Fixed();
        }*/
    
    public JPanel getFrame(){
        return rootPanel;
    }
    }
