package Provident_fund;

//import TEST_SPACE.RoundButton2;
import Homepage.Gframe;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;


public class Provident_fund implements ActionListener,Gframe {
    private double start_age, end_age ,present_salary,increase_rate,asset_value,invest_rate,con_rate,yield_rate;
    private JFrame frame_1;
    private JPanel mainpanel,panel_1, panel_2, panel_2_1, panel_2_2, panel_2_3, panel_2_4, panel_3, panel_3_1, panel_3_2, panel_3_3, panel_3_4, panel_4, panel_5;
    private JLabel label_1, label_2, label_3, label_4, label_5, label_6, label_7, label_8, label_9, label_10, label_11, label_12, label_13, label_14, label_15, label_16, label_17, label_18, label_19, label_20 ;
    private JTextField txt_1, txt_2, txt_3, txt_4, txt_5, txt_6, txt_7, txt_8, txt_9, txt_10;
    private String spacer = "                  ";
    private JButton btn_1,btn_2;
    private int font_size = 30;
    
    private boolean status = false;
    
    private double all_value,total_saving,total_profit;
    public void set_all_value(double data){
        this.all_value = data;
    }
    public void set_total_saving(double data){
        this.total_saving = data;
    }
    public void set_total_profit(double data){
        this.total_profit = data;
    }
    public double get_all_value(){
        return this.all_value;
    }
    public double get_total_saving(){
        return this.total_saving;
    }
    public double get_total_profit(){
        return this.total_profit;
    }
    public JPanel calculated_ui(){
        try {
            start_age = Double.parseDouble(txt_1.getText());
            end_age = Double.parseDouble(txt_2.getText());
            present_salary = Double.parseDouble(txt_3.getText());
            increase_rate = Double.parseDouble(txt_4.getText());
            asset_value = Double.parseDouble(txt_5.getText());
            invest_rate = Double.parseDouble(txt_6.getText());
            con_rate = Double.parseDouble(txt_7.getText());
            yield_rate = Double.parseDouble(txt_8.getText());
        } catch (Exception e) {
        }
        
        
        double total_year = end_age - start_age;
        double total_value = asset_value;
        double salary = present_salary;
        double profit_rate = (yield_rate/12)/100;
        double from_invest = 0;
        double from_saving = 0;
        for (int i = 0; i < total_year; i++){
            
            total_value += (salary*(invest_rate/100));
            total_value += (salary*(con_rate/100));  
            total_value += total_value*profit_rate;    
            
            salary *= 1 + (increase_rate/100) ;
            
            from_invest += total_value*profit_rate;
            from_saving += (salary*(invest_rate/100));
        }
        
        set_all_value(total_value);
        set_total_profit(from_invest);
        set_total_saving(from_saving);
        
        JPanel p1 = new JPanel();
        JPanel p2 = new JPanel();
        JPanel p3 = new JPanel();
        JPanel p4 = new JPanel();
        JPanel p5 = new JPanel();
        
        p1.setLayout(new GridLayout(4,1));
        
        p2.setLayout(new FlowLayout());
        p2.add(new JLabel("You will have "),BorderLayout.WEST);
        p2.add(new JTextField(Double.toString(this.get_all_value())),BorderLayout.CENTER);
        p2.add(new JLabel("Bahts When you retired"),BorderLayout.EAST);
        
        p3.setLayout(new FlowLayout());
        p3.add(new JLabel("You get about "),BorderLayout.WEST);
        p3.add(new JTextField(Double.toString(this.get_total_saving())),BorderLayout.CENTER);
        p3.add(new JLabel("Bahts form Salary saving"),BorderLayout.EAST);
        
        p4.setLayout(new FlowLayout());
        p4.add(new JLabel("You get about "),BorderLayout.WEST);
        p4.add(new JTextField(Double.toString(this.get_total_profit())),BorderLayout.CENTER);
        p4.add(new JLabel("Bahts form your Investment"),BorderLayout.EAST);
        
        p1.add(p2);
        p1.add(p3);
        p1.add(p4);
        
        return p1;
    }
    
    public Provident_fund(){
        mainpanel = new JPanel();
        mainpanel.setLayout(new GridLayout(2,1));
        
        
        //btn_11_1.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        //panel_11.setBorder(BorderFactory.createLineBorder(Color.GRAY,5));
        
        panel_1 = new JPanel();
        panel_1.setLayout(new GridLayout(1,2));
        //panel_1.setBorder(BorderFactory.createLineBorder(Color.GRAY,5));
        
        panel_2 = new JPanel();
        panel_2.setLayout(new GridLayout(4,1,30,30));
        //panel_2.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY,5));

        
        label_1 = new JLabel("present ages");
        label_1.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_2 = new JLabel("years");
        label_2.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_1 = new JTextField("0");
        txt_1.setPreferredSize(new Dimension(200,45));
        txt_1.setFont(new Font("Segoe UI", Font.PLAIN, font_size));

        panel_2_1 = new JPanel();
        panel_2_1.setLayout(new FlowLayout());    
        //panel_2_1.setLayout(new BorderLayout());     
        
        panel_2_1.add(label_1); panel_2_1.add(txt_1); panel_2_1.add(label_2);
        panel_2_1.add(label_1,BorderLayout.WEST); panel_2_1.add(txt_1,BorderLayout.CENTER); panel_2_1.add(label_2,BorderLayout.EAST);
        panel_2.add(panel_2_1);
        
        
        
        
        label_3 = new JLabel("Retired ages ");
        label_3.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_4 = new JLabel(" years");
        label_4.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_2 = new JTextField("0");
        txt_2.setPreferredSize(new Dimension(200,45));
        txt_2.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        
        panel_2_2 = new JPanel();
        panel_2_2.setLayout(new FlowLayout());     
        
        panel_2_2.add(label_3); panel_2_2.add(txt_2); panel_2_2.add(label_4);
        panel_2.add(panel_2_2);
        
        
        
        
        label_5 = new JLabel("present salary");
        label_5.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_6 = new JLabel("Baht / month");
        label_6.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_3 = new JTextField("0");
        txt_3.setPreferredSize(new Dimension(200,45));
        txt_3.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        
        panel_2_3 = new JPanel();
        panel_2_3.setLayout(new FlowLayout());     
        
        panel_2_3.add(label_5); panel_2_3.add(txt_3); panel_2_3.add(label_6);
        panel_2.add(panel_2_3);
        
        
        
        
        label_7 = new JLabel("Salary increase rate");
        label_7.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_8 = new JLabel("baht / year");
        label_8.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_4 = new JTextField("0");
        txt_4.setPreferredSize(new Dimension(200,45));
        txt_4.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        
        panel_2_4 = new JPanel();
        panel_2_4.setLayout(new FlowLayout());     
        
        panel_2_4.add(label_7); panel_2_4.add(txt_4); panel_2_4.add(label_8);
        panel_2.add(panel_2_4);
        
        
        
        
        
        
        //--------------------------------------------------------------------------------------------------------------------------
        panel_3 = new JPanel();
        panel_3.setLayout(new GridLayout(4,1,40,40));
        //panel_3.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY,5));
        
        
        
        label_9 = new JLabel("Total asset value");
        label_9.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_10 = new JLabel("Baht");
        label_10.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_5 = new JTextField("0");
        txt_5.setPreferredSize(new Dimension(200,45));
        txt_5.setFont(new Font("Segoe UI", Font.PLAIN, font_size));

        panel_3_1 = new JPanel();
        panel_3_1.setLayout(new FlowLayout());     

        panel_3_1.add(label_9); panel_3_1.add(txt_5); panel_3_1.add(label_10);
        panel_3.add(panel_3_1);
        
        
        
        
        label_11 = new JLabel("investment rate");
        label_11.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_12 = new JLabel(" % / month");
        label_12.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_6 = new JTextField("0");
        txt_6.setPreferredSize(new Dimension(200,45));
        txt_6.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        
        panel_3_2 = new JPanel();
        panel_3_2.setLayout(new FlowLayout());   
        panel_3_2.add(label_11);panel_3_2.add(txt_6);panel_3_2.add(label_12);
        panel_3.add(panel_3_2);
        
        
        
        
        label_13 = new JLabel("Contribution ratio");
        label_13.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_14 = new JLabel(" % / month");
        label_14.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_7 = new JTextField("0");
        txt_7.setPreferredSize(new Dimension(200,45));
        txt_7.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        
        panel_3_3 = new JPanel();
        panel_3_3.setLayout(new FlowLayout());    
        panel_3_3.add(label_13); panel_3_3.add(txt_7); panel_3_3.add(label_14);
        panel_3.add(panel_3_3);
        
        
        
        label_15 = new JLabel("Yield");
        label_15.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        label_16 = new JLabel(" % / year");
        label_16.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        txt_8 = new JTextField("0");
        txt_8.setPreferredSize(new Dimension(200,45));
        txt_8.setFont(new Font("Segoe UI", Font.PLAIN, font_size));
        
        panel_3_4 = new JPanel();
        panel_3_4.setLayout(new FlowLayout());     
        
        panel_3_4.add(label_15); panel_3_4.add(txt_8); panel_3_4.add(label_16);
        panel_3.add(panel_3_4);
        //-------------------------------------------------------------------------------------------
        panel_4 = new JPanel(new BorderLayout());
        btn_1 = new JButton("Calculate");
        panel_4.add(btn_1,BorderLayout.NORTH);
        btn_1.addActionListener(this);
        //--------------------------------------------------------------------------------------------
        panel_1.add(panel_2);
        panel_1.add(panel_3);
        
        mainpanel.add(panel_1);
        mainpanel.add(panel_4);
        
        
        frame_1 = new JFrame();
        frame_1.add(mainpanel);
        frame_1.setSize(1920, 1080);
        frame_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame_1.setVisible(true);
        
    }
    
    /*public static void main(String[] args) {
        new Provident_fund();
    }*/
    
    public JPanel getFrame(){
        return mainpanel;
    }
    
    public void playSound(String soundName){
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundName).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex){
          System.out.println("Error with playing sound.");
          ex.printStackTrace( );
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        playSound("src/img/mixkit-cool-interface-click-tone-2568.wav");
        Object sc = e.getSource();
        if(sc.equals(btn_1)){
            if(status == false){
                System.out.println("calculated_1");
                panel_4.add(calculated_ui(),BorderLayout.CENTER);
                //mainpanel.add(calculated_ui());
                mainpanel.setVisible(true);
                mainpanel.revalidate();
                mainpanel.repaint();
                //mainpanel.setSize(1920,1080);
                panel_4.setVisible(true);
                //frame_1.setVisible(true);
                status = true;
            }
            else{
                System.out.println("calculated_2");
                panel_4.remove(calculated_ui());
                panel_4.add(calculated_ui(),BorderLayout.CENTER);
                //mainpanel.add(calculated_ui());
                mainpanel.revalidate();
                mainpanel.repaint();
                mainpanel.setVisible(true);
                
                panel_4.setVisible(true);
                //frame_1.setVisible(true);
                status = false;
            }
            
        }
    }
}
