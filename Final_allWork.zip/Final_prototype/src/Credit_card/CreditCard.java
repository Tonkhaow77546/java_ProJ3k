package Credit_card;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Homepage.Gframe;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
/**
 *
 * @author User
 */
public class CreditCard extends JFrame implements ActionListener,Gframe{
    private JFrame jf;
    private TextField tFee;
    private TextField tPerPay;
    private TextField tLessPay;
    private TextField tAmount;
    private TextField tFirstDay;
    private TextField tDDay;
    private JPanel palFaA; //this is "L" not one 
    private JPanel palPerPaPL;
    private JPanel palDayaDD;
    private JPanel palButt;
    private JPanel palAddNoti; 
    private JPanel palSum;
    private JButton buttRe;
    private JButton buttCal;
    private JButton buttAddNoti;
    private JLabel lbInaFee;
    private JLabel lbMini;
    private JLabel lbLower;
    private JLabel lbAmount;
    private JLabel lbFrist;
    private JLabel lbDDay;
    private JLabel lbSAmount;
    private JTextField lbsAAmount;
    private JLabel lbsSInter;
    private JTextField lbsAInter;
    private JLabel lbsSNum;
    private JTextField lbsANum;
    private JLabel lbsSLower;
    private JTextField lbALower;
    private JLabel lbSmini;
    private JTextField lbsAmini;
    private JLabel lbsSInaFee;
    private JTextField lbsAInaFee;
    private JLabel lbNoti;
    private JPanel fpa1; // this one fpa1 = free panel
    private JPanel fpa2;
    private JPanel fpa3;
    private JPanel fpa4;
    private JPanel mpal; // mpal = main panel
    private JPanel pal0;
    private JPanel inputPanel;
    
    private SumInterest si;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    public CreditCard(){
        
        jf = new JFrame("CreditCard");
        jf.setLayout(new GridLayout());
        jf.setSize(1920, 1080);
        
        pal0 = new JPanel();
        pal0.setLayout(new BorderLayout());
        
        fpa1 = new JPanel();
        fpa2 = new JPanel();
        fpa3 = new JPanel();
        fpa4 = new JPanel();
        
        mpal = new JPanel();
        inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        inputPanel.add(mpal);
        mpal.setLayout(new GridLayout(40,1));
        
        tFee = new TextField();
        lbInaFee = new JLabel("Interest and Fee");
        lbInaFee.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tAmount = new TextField();
        lbAmount = new JLabel("Amount");
        lbAmount.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tFee.setPreferredSize(new Dimension(700, 30));
        tAmount.setPreferredSize(new Dimension(700, 30));
        tFee.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tAmount.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(new JPanel());
        tFee.setText("0");
        tAmount.setText("0");
        mpal.add(lbInaFee);
        mpal.add(tFee);
        mpal.add(lbAmount);
        mpal.add(tAmount);
        

        tPerPay = new TextField();
        lbMini = new JLabel("Minimum reimbursement(%)");
        lbMini.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tLessPay = new TextField();
        lbLower = new JLabel("Amount is not lower than");
        lbLower.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tLessPay.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tPerPay.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tPerPay.setText("0");
        tLessPay.setText("0");
        
        mpal.add(lbMini);
        mpal.add(tPerPay);
        mpal.add(lbLower);
        mpal.add(tLessPay);
        
        tDDay = new TextField("dd/mm/yyyy");
        lbFrist = new JLabel("Transaction day");
        lbFrist.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tFirstDay = new TextField("dd/mm/yyyy");
        lbDDay = new JLabel("Payment due date");
        lbDDay.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tFirstDay.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        tDDay.setFont(new Font("Times New Roman", Font.PLAIN, 22));

        mpal.add(lbFrist);
        mpal.add(tFirstDay);
        mpal.add(lbDDay);
        mpal.add(tDDay);
     
        palButt = new JPanel();
        buttRe = new JButton("Reset");
        buttCal = new JButton("Calculate");
        buttRe.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        buttCal.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        palButt.add(buttCal);
        palButt.add(buttRe);
        mpal.add(palButt);
        mpal.add(new JPanel());
        palAddNoti = new JPanel();
        palAddNoti.setLayout(new GridLayout(1, 1));
        lbNoti = new JLabel("Want to add Notification pay date? ");
        lbNoti.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        buttAddNoti = new JButton("Add");
        buttAddNoti.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        
        palAddNoti.add(lbNoti);
        palAddNoti.add(buttAddNoti);
        
        palSum = new JPanel();
        palSum.setLayout(new GridLayout(6, 2));
        lbSAmount = new JLabel();
        lbsAAmount = new JTextField();
        lbsAAmount.setEditable(false);
        lbsSInter = new JLabel();
        lbsAInter = new JTextField();
        lbsAInter.setEditable(false);
        lbsSNum = new JLabel();
        lbsANum = new JTextField();
        lbsANum.setEditable(false);
        lbsSLower = new JLabel();
        lbALower = new JTextField();
        lbALower.setEditable(false);
        lbSmini = new JLabel();
        lbsAmini = new JTextField();
        lbsAmini.setEditable(false);
        lbsSInaFee = new JLabel();
        lbsAInaFee = new JTextField();
        lbsAInaFee.setEditable(false);
        
        lbsAAmount.setVisible(false);
        lbsAInter.setVisible(false);
        lbsANum.setVisible(false);
        lbALower.setVisible(false);
        lbsAmini.setVisible(false);
        lbsAInaFee.setVisible(false);
        
        lbsAAmount.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        lbsAInter.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        lbsANum.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        lbALower.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        lbsAmini.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        lbsAInaFee.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        
        JPanel amountPanel = new JPanel(new GridLayout(1,2) );
        amountPanel.add(lbSAmount);
        amountPanel.add(lbsAAmount);
        lbSAmount.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        lbsAAmount.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(amountPanel);
        
        JPanel lbsPanel = new JPanel(new GridLayout(1,2));
        lbsPanel.add(lbsSInter);
        lbsPanel.add(lbsAInter);
        lbsSInter.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        lbsAInter.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(lbsPanel);
        
        JPanel snumPanel = new JPanel(new GridLayout(1,2));
        snumPanel.add(lbsSNum);
        snumPanel.add(lbsANum);
        lbsSNum.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        lbsANum.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(snumPanel);
        
        JPanel lowerPanel = new JPanel(new GridLayout(1,2));
        lowerPanel.add(lbsSLower);
        lowerPanel.add(lbALower);
        lbsSLower.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        lbALower.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(lowerPanel);
        
        JPanel miniPanel = new JPanel(new GridLayout(1,2));
        miniPanel.add(lbSmini);
        miniPanel.add(lbsAmini);
        lbSmini.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        lbsAmini.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(miniPanel);
        
        JPanel  inaPanel = new JPanel(new GridLayout(1,2));
        inaPanel.add(lbsSInaFee);
        inaPanel.add(lbsAInaFee);
        lbsSInaFee.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        lbsAInaFee.setFont(new Font("Times New Roman", Font.PLAIN, 22));
        mpal.add(inaPanel);
        
        buttRe.addActionListener(this);
        buttCal.addActionListener(this);
        buttAddNoti.addActionListener(this);
        
        pal0.add(inputPanel, BorderLayout.CENTER);
        
        jf.add(pal0);
        
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //jf.setVisible(true);
        
    }
        
    @Override    
    public void actionPerformed(ActionEvent e) {
        Object sc = e.getSource();
        if (sc.equals(buttRe)) {
            tFee.setText("0");
            tPerPay.setText("0");
            tLessPay.setText("0");
            tAmount.setText("0");
            tFirstDay.setText("dd/mm/yyyy");
            tDDay.setText("dd/mm/yyyy");
            
            lbSAmount.setText("");
            lbsSInter.setText("");
            lbsSNum.setText("");
            lbsSLower.setText("");
            lbSmini.setText("");
            lbsSInaFee.setText("");

            lbsAAmount.setText("");
            lbsAInter.setText("");
            lbsANum.setText("");
            lbALower.setText("");
            lbsAmini.setText("");
            lbsAInaFee.setText("");
            lbsAAmount.setVisible(false);
            lbsAInter.setVisible(false);
            lbsANum.setVisible(false);
            lbALower.setVisible(false);
            lbsAmini.setVisible(false);
            lbsAInaFee.setVisible(false);
            
            lbNoti.setVisible(false);
            buttAddNoti.setVisible(false);
        } else if (sc.equals(buttCal)) {
            try{
                this.si = new SumInterest(365, 2);
                
                if (Integer.valueOf(tAmount.getText()) <= 0 || Integer.valueOf(tFee.getText())<= 0 || Integer.valueOf(tLessPay.getText()) < 0 || Integer.valueOf(tPerPay.getText()) < 0) {
                    throw new IllegalArgumentException("Please enter valid values (greater than 0).");
                }
                
                if (tFirstDay.getText().length() != 10 || tDDay.getText().length() != 10){
                    throw new IllegalArgumentException("Please enter the date like dd/mm/yyyy");
                }
                if (Integer.valueOf(tFirstDay.getText().substring(3, 5)) > 12 || Integer.valueOf(tFirstDay.getText().substring(3, 5)) < 1 || Integer.valueOf(tDDay.getText().substring(3, 5)) > 12 || Integer.valueOf(tDDay.getText().substring(3, 5)) < 1){
                    throw new IllegalArgumentException("Please enter the date like dd/mm/yyyy (if one digit number fill 0)");
                }
                if (Integer.valueOf(tFirstDay.getText().substring(0, 2)) > 31 || Integer.valueOf(tFirstDay.getText().substring(0, 2)) < 1 || Integer.valueOf(tDDay.getText().substring(0, 2)) > 31 || Integer.valueOf(tDDay.getText().substring(0, 2)) < 1){
                    throw new IllegalArgumentException("Please enter the date like dd/mm/yyyy (if one digit number fill 0)");
                }
                si.setDaysBe(LocalDate.parse(tFirstDay.getText(), formatter), LocalDate.parse(tDDay.getText(), formatter));
                
                if(si.getDaysBe() < 0){
                    throw new IllegalArgumentException("Please enter date Transaction day before Payment due date");
                }
                si.CheckLeap(Integer.valueOf((tFirstDay.getText()).substring(6)));
                si.ManyDay();
                si.setAmount(Integer.valueOf(tAmount.getText()));
                si.setPay(Integer.valueOf(tLessPay.getText()), Integer.valueOf(tPerPay.getText()), Double.valueOf(tAmount.getText()));
                si.setFee(Double.valueOf(tFee.getText()));
                
                
                lbSAmount.setText("Amount");
                lbsSInter.setText("All Interest");
                lbsSNum.setText("Number of installments");
                lbsSLower.setText("Amount is not lower than");
                lbSmini.setText("Minimum reimbursement(%)");
                lbsSInaFee.setText("Interest and Fee");

                lbsAAmount.setText(tAmount.getText());
                lbsAInter.setText(String.valueOf(si.getTFee()));
                lbsANum.setText(String.valueOf(si.getTime()));
                lbALower.setText(tLessPay.getText());
                lbsAmini.setText(tPerPay.getText());
                lbsAInaFee.setText(tFee.getText());
                
                lbsAAmount.setVisible(true);
                lbsAInter.setVisible(true);
                lbsANum.setVisible(true);
                lbALower.setVisible(true);
                lbsAmini.setVisible(true);
                lbsAInaFee.setVisible(true);
               
                lbNoti.setVisible(true);
                buttAddNoti.setVisible(true);
                mpal.add(palAddNoti);
                
                
                if (sc.equals(buttRe)) {
                    si.setDayCount(LocalDate.parse(tDDay.getText(), formatter));
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
                tFee.setText("0");
                tPerPay.setText("0");
                tLessPay.setText("0");
                tAmount.setText("0");
                tFirstDay.setText("dd/mm/yyyy");
                tDDay.setText("dd/mm/yyyy");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
                tFee.setText("0");
                tPerPay.setText("0");
                tLessPay.setText("0");
                tAmount.setText("0");
                tFirstDay.setText("dd/mm/yyyy");
                tDDay.setText("dd/mm/yyyy");
            }
    }
}
    public JPanel getFrame(){
        return pal0;
    }
    
    public static void main(String[] args) {
        new CreditCard();
    }
}


//cr: https://www.ktc.co.th/article/knowledge/credit-card-interest-charge-method