package Log_In;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UserCreation extends JFrame {
    // MySQL database URL

    JLabel usernameLabel, passwordLabel, nameLabel;
    JTextField usernameField, passwordField, nameField;
    JButton createUserButton;

    public UserCreation() {
        setSize(500, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        nameField = new JTextField(20);
        nameField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        createUserButton = new JButton("Create User");
        createUserButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));

        createUserButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = passwordField.getText();
                String name = nameField.getText();

                try {
                    Register register = new Register();
                    register.createTable(); //if no table
                    register.createUser(username, password, name);
                    dispose();
                    new Login();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(UserCreation.this, "Error creating user: " + ex.getMessage());
                }
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4,1));
        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        JPanel p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        JPanel p4 = new JPanel();
        p4.setLayout(new FlowLayout());
        
        p1.add(usernameLabel);
        p1.add(usernameField);
        p2.add(passwordLabel);
        p2.add(passwordField);
        p3.add(nameLabel);
        p3.add(nameField);
        p4.add(createUserButton);
        
        panel.add(p1);
        panel.add(p2);
        panel.add(p3);
        panel.add(p4);
        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new UserCreation();
            }
        });
    }
}