package short_saving;

import java.util.Calendar;

public class SaveMoney{
    private int day;
    private double begin;
    private double moneyWant;
   
    public SaveMoney(){
        this(0, 0, 0);
    }
    
    public SaveMoney(int day, double moneyWant, double begin){
        setDay(day);
        setMoneyWant(moneyWant);
        setBegin(begin);
    }
    
        public void setDay(int day){
        this.day= day;
    }
    
    public int getDay(){
        return day;
    }
    
    public void setMoneyWant(double moneyWant){
        this.moneyWant = moneyWant;
    }
    
    public double getMoneyWant(){
        return moneyWant;
    }
    
    public void setBegin(double begin){
        this.begin = begin;
    }
    
    public double getBegin(){
        return begin;
    }
    
    public double Calculate(Calendar startDate, Calendar endDate) {
        //credit https://fwebsolution.blogspot.com/2012/04/java-carlendar.html?m=1
        Calendar date = (Calendar) startDate.clone();
        int daysBetween = 0;
        while (date.before(endDate)) {
          date.add(Calendar.DAY_OF_MONTH, 1);
          daysBetween++;
        }
        return (getMoneyWant()-getBegin())/(daysBetween);
   }
}