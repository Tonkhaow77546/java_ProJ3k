package short_saving;

import CustomException.DayException;
import CustomException.MinusException;
import Homepage.Gframe;
import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SaveMoneyUI implements ActionListener,Gframe {
    private JPanel mainPanel, subPanel1, panelFrame;
    private JPanel subButton, subResult;
    private JLabel JAmountLabel, JChoser1Label, JChoser2Label, JBeginLable, JResult1;
    private JTextField JAmount, JBeginText, JResult2;
    private JButton JSummitButton, JResetButton;
    private JDateChooser chooser1, chooser2;
    private SaveMoney saveMoneyFn;
    private JFrame frame;

    public SaveMoneyUI() {
        saveMoneyFn = new SaveMoney();
        generateUI();
    }

    public void generateUI() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1080);
        
        panelFrame = new JPanel(new BorderLayout());
        panelFrame.setSize(1920, 1080);
        
        frame.add(panelFrame);

        mainPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        mainPanel.setSize(1920, 1080);
        panelFrame.add(mainPanel, BorderLayout.CENTER);

        subPanel1 = new JPanel(new GridLayout(14, 1));
        mainPanel.add(subPanel1, BorderLayout.CENTER);

        subPanel1.add(new Panel());
        
        JAmountLabel = new JLabel("Required amount (baht)", SwingConstants.LEFT);
        JAmountLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JAmount = new JTextField("0");
        JAmount.setPreferredSize(new Dimension(400, 30));
        JAmount.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subPanel1.add(JAmountLabel);
        subPanel1.add(JAmount);

        JChoser1Label = new JLabel("Start Date", SwingConstants.LEFT);
        JChoser1Label.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        chooser1 = new JDateChooser();
        chooser1.setPreferredSize(new Dimension(300, 25));
        chooser1.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subPanel1.add(JChoser1Label);
        subPanel1.add(chooser1);

        JChoser2Label = new JLabel("End Date", SwingConstants.LEFT);
        JChoser2Label.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        chooser2 = new JDateChooser();
        chooser2.setPreferredSize(new Dimension(300, 25));
        chooser2.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subPanel1.add(JChoser2Label);
        subPanel1.add(chooser2);

        JBeginLable = new JLabel("Starting money (baht)", SwingConstants.LEFT);
        JBeginLable.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JBeginText = new JTextField("0");
        JBeginText.setPreferredSize(new Dimension(300, 25));
        JBeginText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subPanel1.add(JBeginLable);
        subPanel1.add(JBeginText);
        subPanel1.add(new JPanel());

        subButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JSummitButton = new JButton("Calculate");
        JResetButton = new JButton("Reset");
        JSummitButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JResetButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subButton.add(JSummitButton);
        subButton.add(JResetButton);
        subPanel1.add(subButton);
        subPanel1.add(new JPanel());
        
        subResult = new JPanel(new GridLayout(1, 2));
        JResult1 = new JLabel("Daily collection amount is ");
        JResult1.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subResult.add(JResult1);
        JResult2 = new JTextField("");
        JResult2.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JResult2.setEditable(false);
        JResult2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        subResult.add(JResult2);
        subPanel1.add(subResult);
        subResult.setVisible(false);
        
        JSummitButton.addActionListener(this);
        JResetButton.addActionListener(this);
        
        //frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(JSummitButton)) {
            try {
                double i = Double.parseDouble(JAmount.getText());
                double j = Double.parseDouble(JBeginText.getText());
                if (chooser1.getDate().getTime() > chooser2.getDate().getTime()) {
                    throw new DayException("The end date cannot be less than the start date.");
                }
                if(Double.parseDouble(JAmount.getText()) < 0 || Double.parseDouble(JBeginText.getText()) < 0){
                    throw new MinusException("You cannot enter negative numbers.");
                }
                SaveMoneySetValue();
                setEditAllTextField(false);
                JResult2.setText(String.valueOf((int)saveMoneyFn.Calculate(chooser1.getCalendar(), chooser2.getCalendar())));
                subResult.setVisible(true);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "The information entered cannot be characters.", "WARNING", JOptionPane.WARNING_MESSAGE);
            } catch (DayException ex) {
                JOptionPane.showMessageDialog(null, "The end date cannot be less than the start date..", "WARNING", JOptionPane.WARNING_MESSAGE);
            } catch (MinusException ex) {
                JOptionPane.showMessageDialog(null, "You cannot enter negative numbers.","WARNING",  JOptionPane.WARNING_MESSAGE);
            }
        }
        else if (e.getSource().equals(JResetButton)) {
            textFieldAllSet("0");
            setEditAllTextField(true);
            subResult.setVisible(false);
        }
    }

    public void SaveMoneySetValue() {
        saveMoneyFn.setMoneyWant(Double.parseDouble(JAmount.getText()));
        saveMoneyFn.setBegin(Double.parseDouble(JBeginText.getText()));
    }

    public void textFieldAllSet(String data) {
        JAmount.setText(data);
        JBeginText.setText(data);
        chooser1.setToolTipText("");
        chooser2.setToolTipText("");
    }

    public void setEditAllTextField(boolean data) {
        JAmount.setEditable(data);
        JBeginText.setEditable(data);
        chooser1.setEnabled(data);
        chooser2.setEnabled(data);
    }
    
    public JPanel getFrame() {
        return panelFrame;
    }
    
    /*public static void main(String[] args) {
        new SaveMoneyUI();
    }*/
}
