package Taxes;

public interface Tax_Percentage {
    
    public abstract double ladder_Tax(double money);
}
