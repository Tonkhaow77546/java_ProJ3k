package Product_installments;

import Homepage.Gframe;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.border.TitledBorder;


public class InstallmentApp extends JFrame implements ActionListener,Gframe {
    private JFrame frame;
    private JTextField originalField;
    private JTextField installmentField;
    private JTextField interestField;
    private JTextField daysLeftField;
    private JTextField installmentDueField;
    private JButton calculateButton;
    private JButton resetButton;
    private JLabel paymentPerInstallmentLabel;
    private JLabel remainingInstallmentsLabel;
    private JLabel nextDaysLabel;
    private JLabel everyDaysLabel;
    private JTextField paidInstallmentsField;

    public InstallmentApp() {
        //setTitle("Installment Calculator");
        //setSize(1920, 1080);
        //setDefaultCloseOperation(EXIT_ON_CLOSE);
        //setLayout(new BorderLayout());
        //setLocationRelativeTo(null);
        
        frame = new JFrame("Product Installment");
        frame.setSize(1920, 1080);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setLocationRelativeTo(null);
        //frame.pack();
        
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2,30,30));
        //inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        

        originalField = new JTextField();
        originalField.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        installmentField = new JTextField();
        installmentField.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        interestField = new JTextField();
        interestField.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        daysLeftField = new JTextField("0");
        daysLeftField.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        installmentDueField = new JTextField("0");
        installmentDueField.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        paidInstallmentsField = new JTextField("0");
        paidInstallmentsField.setFont(new Font("Times New Roman", Font.PLAIN, 30));

        inputPanel.add(new JLabel("  Original Price:")).setFont(new Font("Times New Roman", Font.PLAIN, 30));
        inputPanel.add(originalField);
        inputPanel.add(new JLabel("  Number of Installments:")).setFont(new Font("Times New Roman", Font.PLAIN, 30));
        inputPanel.add(installmentField);
        inputPanel.add(new JLabel("  Interest Rate (% per installment):")).setFont(new Font("Times New Roman", Font.PLAIN, 30));
        inputPanel.add(interestField);
        inputPanel.add(new JLabel("  Days before next installment:")).setFont(new Font("Times New Roman", Font.PLAIN, 30));
        inputPanel.add(daysLeftField);
        inputPanel.add(new JLabel("  Installment due every (days):")).setFont(new Font("Times New Roman", Font.PLAIN, 30));
        inputPanel.add(installmentDueField);
        inputPanel.add(new JLabel("  Paid Installments:")).setFont(new Font("Times New Roman", Font.PLAIN, 30));
        inputPanel.add(paidInstallmentsField);
        
        TitledBorder inputBorder = BorderFactory.createTitledBorder("Input Details");
        inputBorder.setTitleJustification(TitledBorder.CENTER);
        inputPanel.setBorder(inputBorder);
        inputPanel.setBackground(Color.WHITE);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        //buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        calculateButton = new JButton("Calculate");
        calculateButton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        resetButton.addActionListener(this);
        buttonPanel.add(resetButton);
        
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);


        paymentPerInstallmentLabel = new JLabel("");
        remainingInstallmentsLabel = new JLabel("");
        nextDaysLabel = new JLabel("");
        everyDaysLabel = new JLabel("");

        JPanel resultPanel = new JPanel(new GridLayout(5, 1));
        //resultPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel x1 = new JLabel("Details");
        x1.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        x1.setHorizontalAlignment(JLabel.CENTER);
        resultPanel.add(x1);
        resultPanel.add(paymentPerInstallmentLabel);
        resultPanel.add(remainingInstallmentsLabel);
        resultPanel.add(nextDaysLabel);
        resultPanel.add(everyDaysLabel);
        
        TitledBorder titledBorder = BorderFactory.createTitledBorder("Payment Details");
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        resultPanel.setBorder(titledBorder);
        resultPanel.setBackground(Color.WHITE);
        
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(buttonPanel, BorderLayout.NORTH);
        bottomPanel.add(resultPanel, BorderLayout.CENTER);

        frame.add(bottomPanel, BorderLayout.CENTER);
        //frame.add(inputPanel);
        //frame.add(buttonPanel);
        //frame.add(resultPanel);
    }

    private JLabel createBigLabel(String text) {
        JLabel label = new JLabel("<html><h2>" + text + "</h2></html>");
        label.setHorizontalAlignment(JLabel.CENTER);
        return label;
    }
    
    public JPanel getFrame() {
        return (JPanel)frame.getContentPane();
    }
    
    public void actionPerformed(ActionEvent e) {
    if (e.getSource() == calculateButton) {
        try {
            double original = Double.parseDouble(originalField.getText());
            int installment = Integer.parseInt(installmentField.getText());
            double interest = Double.parseDouble(interestField.getText());
            int daysLeft = Integer.parseInt(daysLeftField.getText());
            int installmentDue = Integer.parseInt(installmentDueField.getText());
            int paidInstallments = Integer.parseInt(paidInstallmentsField.getText());

            if (original <= 0 || installment <= 0 || interest < 0 || paidInstallments < 0) {
                throw new IllegalArgumentException("Please enter valid values (greater than 0).");
            }

            Date futureInstallmentDate = new Date(daysLeft);
            remainingInstallmentsLabel.setText("Next installment due on: " + futureInstallmentDate.toString());
            remainingInstallmentsLabel.setHorizontalAlignment(JLabel.CENTER);

            Date nextInstallmentDate = new Date(daysLeft + installmentDue);
            Date currentDate = new Date();
            Date futureDate = new Date(daysLeft);

            double installmentAmount = (original * (1 + (interest / 100))) / installment;
            double remainingInstallments = (original * (1 + (interest / 100))) - (installmentAmount * paidInstallments);

            if (paidInstallments >= installment) {
                remainingInstallmentsLabel.setText("All installments paid");
                paymentPerInstallmentLabel.setText("");
                nextDaysLabel.setText("");
                everyDaysLabel.setText("");
            } else {
                paymentPerInstallmentLabel.setText("Amount per installment: " + installmentAmount);
                paymentPerInstallmentLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
                paymentPerInstallmentLabel.setHorizontalAlignment(JLabel.CENTER);

                remainingInstallmentsLabel.setText("Remaining installments: " + remainingInstallments);
                remainingInstallmentsLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
                remainingInstallmentsLabel.setHorizontalAlignment(JLabel.CENTER);
                
                if (daysLeft == 0) {
                nextDaysLabel.setText("Pay Now!");
                nextDaysLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
                nextDaysLabel.setHorizontalAlignment(JLabel.CENTER);
                
                } else{nextDaysLabel.setText("Next Installment Date " + futureDate.toString());
                nextDaysLabel.setHorizontalAlignment(JLabel.CENTER);
                }

                if (installmentDue == 0) {
                everyDaysLabel.setText("No more installments");
                everyDaysLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
                everyDaysLabel.setHorizontalAlignment(JLabel.CENTER);
                
                } else{everyDaysLabel.setText( "Future Installment Date " + nextInstallmentDate.toString() );
                everyDaysLabel.setHorizontalAlignment(JLabel.CENTER);
                everyDaysLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
                }
            }
            calculateButton.setText("Update Remaining Payment");
            
            calculateButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    remainingInstallmentsLabel.setText("Remaining Payment: " + remainingInstallments);
                }
            });
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
            paymentPerInstallmentLabel.setText("");
            remainingInstallmentsLabel.setText("");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            paymentPerInstallmentLabel.setText("");
            remainingInstallmentsLabel.setText("");
        }
    }
    else if (e.getSource() == resetButton) {
            originalField.setText("");
            installmentField.setText("");
            interestField.setText("");
            daysLeftField.setText("");
            installmentDueField.setText("");
            paidInstallmentsField.setText("0");
            paymentPerInstallmentLabel.setText("");
            remainingInstallmentsLabel.setText("");
            nextDaysLabel.setText("");
            everyDaysLabel.setText("");
        }
}

    /*public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InstallmentApp app = new InstallmentApp();
            app.frame.setVisible(true);
        });
    }*/
    
}