package retirement;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import CustomException.AgeException;
import CustomException.MinusException;
import CustomException.RetireAgeException;
import Homepage.Gframe;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class RetireUI implements ActionListener,Gframe{
    private JPanel mainPanel, subPanel1, panelFrame;
    private JPanel subButton,  subResult1_1, subResult1_2;
    private JLabel JAgeLabel, JAgeRetireLabel, JMoneyAfterRetireLabel, JEndOfLifeLabel, JInflationLable, JBeginLable, result1Lable, result2Lable;
    private JTextField JResult1, JResult2;
    private JPanel part1, part2, part3, part4, part5, part6;
    private JTextField JAgeResultText, JAgeRetireResultText, JMoneyAfterRetireText, JEndOfLifeText, JInflationText, JBeginText;
    private JButton JSummitButton, JResetButton;
    private Retire retireFn;
//    private JFrame frame;
    
    public RetireUI(){
        retireFn = new Retire();
        generateUI();
    }
    
    public void generateUI(){
//        frame = new JFrame();
//        frame.setSize(1920,1080);
        
        panelFrame = new JPanel(new BorderLayout());
        panelFrame.setSize(1920, 1080);
        
//        frame.add(panelFrame);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        mainPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelFrame.add(mainPanel, BorderLayout.CENTER);
        JPanel panelResult = new JPanel();
        panelFrame.add(panelResult, BorderLayout.SOUTH);
        
        subPanel1 = new JPanel(new GridLayout(14, 1));
        subPanel1.add(new JPanel());
        mainPanel.add(subPanel1, BorderLayout.CENTER);
        
        part1 = new JPanel(new GridLayout(2,1));
        JAgeLabel = new JLabel("Your age (year)", SwingConstants.LEFT);
        JAgeLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part1.add(JAgeLabel);        
        JAgeResultText = new JTextField("0");
        JAgeResultText.setPreferredSize(new Dimension(500,30));
        JAgeResultText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part1.add(JAgeResultText);
        subPanel1.add(part1);
        
        part2 = new JPanel(new GridLayout(2,1));
        JAgeRetireLabel= new JLabel("Retire at age (year)", SwingConstants.LEFT);
        JAgeRetireLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part2.add(JAgeRetireLabel);  
        JAgeRetireResultText= new JTextField("0");
        JAgeRetireResultText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part2.add(JAgeRetireResultText);
        subPanel1.add(part2);
        
        part3 = new JPanel(new GridLayout(2,1));
        JMoneyAfterRetireLabel = new JLabel("Expenses after retirement (baht per month)", SwingConstants.LEFT);
        JMoneyAfterRetireLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part3.add(JMoneyAfterRetireLabel);      
        JMoneyAfterRetireText= new JTextField("0");
        JMoneyAfterRetireText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part3.add(JMoneyAfterRetireText);
        subPanel1.add(part3);
        
        part4 = new JPanel(new GridLayout(2,1));
        JEndOfLifeLabel = new JLabel("Lifespan (year) ", SwingConstants.LEFT);
        JEndOfLifeLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part4.add(JEndOfLifeLabel);    
        JEndOfLifeText= new JTextField("0");
        JEndOfLifeText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part4.add(JEndOfLifeText);
        subPanel1.add(part4);
        
        part5 = new JPanel(new GridLayout(2,1));
        JInflationLable= new JLabel("Inflation rate (%)", SwingConstants.LEFT);
        JInflationLable.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part5.add( JInflationLable);  
        JInflationText= new JTextField("0");
        JInflationText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part5.add(JInflationText);
        subPanel1.add(part5);
        
        part6 = new JPanel(new GridLayout(2,1));
        JBeginLable= new JLabel("Starting money (baht)", SwingConstants.LEFT);
        JBeginLable.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part6.add( JBeginLable);
        JBeginText = new JTextField("0");
        JBeginText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        part6.add(JBeginText);
        subPanel1.add(part6);
        
        subButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JSummitButton = new JButton("Calculate");
        JResetButton = new JButton("Reset");
        JSummitButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JResetButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subButton.add(JSummitButton);
        subButton.add(JResetButton);
        subPanel1.add(new JPanel());
        subPanel1.add(subButton);
        subPanel1.add(new JPanel());
        
        subResult1_1 = new JPanel(new GridLayout(1,2));
        subResult1_2 = new JPanel(new GridLayout(1,2));
        
        result1Lable = new JLabel("Total required amount is ");
        result1Lable.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subResult1_1.add(result1Lable);
        JResult1 = new  JTextField("");
        JResult1.setEditable(false);
        JResult1.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subResult1_1.add(JResult1);
        subPanel1.add(subResult1_1);
        
        result2Lable = new JLabel("Monthly savings amount is ");
        result2Lable.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subResult1_2.add(result2Lable);
        JResult2 = new JTextField("");
        JResult2.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subResult1_2.add(JResult2);
        JResult2.setEditable(false);
        subPanel1.add(subResult1_2);
        
        JResult1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        JResult2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
                
        subResult1_1.setVisible(false);
        subResult1_2.setVisible(false);
   

        JSummitButton.addActionListener(this);
        JResetButton.addActionListener(this);
        
//        frame.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){    
        if(e.getSource().equals(JSummitButton)){
            try{
                if(Integer.parseInt(JAgeResultText.getText()) > Integer.parseInt(JAgeRetireResultText.getText())){
                    throw new AgeException("The retirement age cannot be less than the current age.");
                }
                if(Integer.parseInt(JEndOfLifeText.getText()) < Integer.parseInt(JAgeRetireResultText.getText())){
                    throw new RetireAgeException("Life expectancy cannot be less than retirement age.");
                }
                if(Integer.parseInt(JEndOfLifeText.getText()) < 0 || Integer.parseInt(JAgeRetireResultText.getText()) < 0
                  || Double.parseDouble(JBeginText.getText()) < 0 || Double.parseDouble(JMoneyAfterRetireText.getText()) < 0
                  || Double.parseDouble(JInflationText.getText()) < 0 || Integer.parseInt(JAgeResultText.getText()) < 0){
                    throw new MinusException("You cannot enter negative numbers.");
                }
                retireSetValue();
                setEditAllTextField(false);
                JResult1.setText(String.valueOf((int)retireFn.calculateAll()));
                JResult2.setText(String.valueOf((int)retireFn.calculatePerMonth()));
                subResult1_1.setVisible(true);
                subResult1_2.setVisible(true);
            }
            catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(null, "The information entered cannot be characters.","WARNING",  JOptionPane.WARNING_MESSAGE);
            }
            catch (AgeException ex) {
                JOptionPane.showMessageDialog(null, "The retirement age cannot be less than the current age.","WARNING",  JOptionPane.WARNING_MESSAGE);
            }
            catch (RetireAgeException ex) {
                JOptionPane.showMessageDialog(null, "Life expectancy cannot be less than retirement age.","WARNING",  JOptionPane.WARNING_MESSAGE);
            }
            catch (MinusException ex) {
                JOptionPane.showMessageDialog(null, "You cannot enter negative numbers.","WARNING",  JOptionPane.WARNING_MESSAGE);
            }
        }       
        else if(e.getSource().equals(JResetButton)){
            textFieldAllSet("0");
            setEditAllTextField(true);
            JResult1.setText("");
            JResult2.setText("");
            subResult1_1.setVisible(false);
            subResult1_2.setVisible(false);
        }
    }
    
    public void retireSetValue(){
        retireFn.setAge(Integer.parseInt(JAgeResultText.getText()));
        retireFn.setBegin(Double.parseDouble(JBeginText.getText()));
        retireFn.setDieAge(Integer.parseInt(JEndOfLifeText.getText()));
        retireFn.setExpen(Double.parseDouble(JMoneyAfterRetireText.getText()));
        retireFn.setInflation(Double.parseDouble(JInflationText.getText()));
        retireFn.setRetireAge(Integer.parseInt(JAgeRetireResultText.getText()));
    }
    
    public void textFieldAllSet(String data){
        JAgeResultText.setText(data);
        JBeginText.setText(data);
        JEndOfLifeText.setText(data);
        JMoneyAfterRetireText.setText(data);
        JInflationText.setText(data);
        JAgeRetireResultText.setText(data);
    }
    
    public void setEditAllTextField(boolean data){
        JAgeResultText.setEditable(data);
        JBeginText.setEditable(data);
        JEndOfLifeText.setEditable(data);
        JMoneyAfterRetireText.setEditable(data);
        JInflationText.setEditable(data);
        JAgeRetireResultText.setEditable(data);
    }
    
    public JPanel getFrame(){
        return panelFrame;
    }
    
//    public static void main(String[] args) {
//        new RetireUI();
//    }
 }