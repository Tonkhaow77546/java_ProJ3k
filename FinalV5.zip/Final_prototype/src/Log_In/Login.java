package Log_In;

import Homepage.HomePage;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Login extends JFrame {

    JLabel usernameLabel, passwordLabel;
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, createbutton;

    public Login() {
        setSize(500,300);
        setLocationRelativeTo(null);
        
        setResizable(false);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        createbutton = new JButton("Create Account");
        createbutton.setFont(new Font("Times New Roman", Font.PLAIN, 24));

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = passwordField.getText();

                try {
                    Register register = new Register();
                    register.createTable();
                    Object[] UserInfo = register.Login(username, password);
                    if (UserInfo[0].equals(true)){
                        JOptionPane.showMessageDialog(Login.this, "Login successful!");
                        dispose();
                        try {
                            new HomePage((AccountDetail)UserInfo[1]);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (InstantiationException ex) {
                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(Login.this, "Invalid username or password.");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Login.this, "Error: " + ex.getMessage());
                }
            }
        });
        
        createbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new UserCreation();
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3,1));
        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout());
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        JPanel p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        
        p1.add(usernameLabel);
        p1.add(usernameField);
        p2.add(passwordLabel);
        p2.add(passwordField);
        p3.add(loginButton);
        p3.add(createbutton);

        panel.add(p1);
        panel.add(p2);
        panel.add(p3);
        add(panel);
        
        setVisible(true);
    }

//    private Object[] isValidUser(Connection conn, String username, String password) throws SQLException {
//        String sql = "SELECT name, admin, id FROM Users WHERE username = ? AND password = ?";
//        PreparedStatement preparedStatement = conn.prepareStatement(sql);
//        preparedStatement.setString(1, username);
//        preparedStatement.setString(2, password);
//        ResultSet rs = preparedStatement.executeQuery();
//        if (rs.next()) {
//            String name = rs.getString("name");
//            boolean isAdmin = rs.getBoolean("admin");
//            int id = rs.getInt("id");
//            rs.close();
//            preparedStatement.close();
//            return new Object[]{true, name, isAdmin, id};
//        } else {
//            rs.close();
//            preparedStatement.close();
//            return new Object[]{false, null, null};
//        }
//    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Login();
            }
        });
    }
}
