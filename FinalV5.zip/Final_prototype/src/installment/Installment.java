package installment;

import Homepage.Gframe;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Installment extends JFrame implements ActionListener,Gframe {
    private JFrame frame;
    private JPanel mainInput, input, buttonPanel;
    private JPanel amountPanel, totalPanel, installPanel; 
    private JTextField priceField, paymentField, rateField, yearsField, amountField, totalField, installField;
    private JLabel priceLabel, paymentLabel, rateLabel, yearsLabel, amountLabel, totalLabel, installLabel;
    private int priceNum, paymentNum, rateNum, yearsNum, amountNum, totalNum, installNum;
    private JButton clear, calculate;
    private JPanel main_panel;
    
    public JPanel getFrame(){
        return main_panel;
    }
    
    public Installment(){
        frame = new JFrame("Installments");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1920, 1080);
        
        main_panel = new JPanel(new BorderLayout());
        frame.add(main_panel, BorderLayout.CENTER);
        
        input = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        main_panel.add(input, BorderLayout.CENTER);
        
        priceField = new JTextField("0");
        priceField.setPreferredSize(new Dimension(500,30));
        priceLabel = new JLabel("Price (Bath)");
        priceLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        paymentField = new JTextField("0");
        paymentLabel = new JLabel("Down payment (Bath)");
        paymentLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        rateField = new JTextField("0");
        rateLabel = new JLabel("Interest rate (%)");
        rateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        yearsField = new JTextField("0");
        yearsLabel = new JLabel("Years");
        yearsLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        calculate = new JButton("Calculate");
        calculate.setPreferredSize(new Dimension(100,30));
        calculate.addActionListener(this);
        clear = new JButton("Clear");
        clear.setPreferredSize(new Dimension(100,30));
        clear.addActionListener(this);
        
        amountField  = new JTextField(String.valueOf(amountNum));
        amountField.setEditable(false);
        amountLabel = new JLabel("Financing amount (Bath)");
        amountLabel.setHorizontalAlignment(0);
        totalField = new JTextField(String.valueOf(totalNum));
        totalField.setEditable(false);
        totalLabel = new JLabel("Total (Bath)");
        totalLabel.setHorizontalAlignment(0);
        installField = new JTextField(String.valueOf(installNum));
        installLabel = new JLabel("Installment/Month (Bath)");
        installLabel.setHorizontalAlignment(0);
        installField.setEditable(false);

        priceField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        paymentField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        rateField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        yearsField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        calculate.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        calculate.setPreferredSize(new Dimension(150, 30));
        clear.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        clear.setPreferredSize(new Dimension(150, 30));
        
        mainInput = new JPanel();
        mainInput.setLayout(new GridLayout(15,1));
        mainInput.add(new JPanel());
        mainInput.add(priceLabel);                                       
        mainInput.add(priceField);
        mainInput.add(paymentLabel);                                     
        mainInput.add(paymentField);
        mainInput.add(rateLabel);                                        
        mainInput.add(rateField);
        mainInput.add(yearsLabel);                                       
        mainInput.add(yearsField);
        mainInput.add(new JPanel());
        
        buttonPanel = new JPanel();
        buttonPanel.add(calculate);
        buttonPanel.add(clear);
        mainInput.add(buttonPanel);
        mainInput.add(new JPanel());
        
        amountPanel = new JPanel(new GridLayout(1,2));
        amountPanel.add(amountLabel);
        amountPanel.add(amountField);
        amountLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        amountField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        amountField.setHorizontalAlignment(SwingConstants.CENTER);
        amountPanel.setVisible(false);
        mainInput.add(amountPanel);
          
        totalPanel = new JPanel(new GridLayout(1,2));
        totalPanel.add(totalLabel);
        totalPanel.add(totalField);
        totalLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        totalLabel.setHorizontalAlignment(SwingConstants.LEFT);
        totalField.setHorizontalAlignment(SwingConstants.CENTER);
        totalField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        totalPanel.setVisible(false);
        mainInput.add(totalPanel);
          
        installPanel = new JPanel(new GridLayout(1,2));
        installPanel.add(installLabel);
        installPanel.add(installField);
        installLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        installLabel.setHorizontalAlignment(SwingConstants.LEFT);
        installField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        installField.setHorizontalAlignment(SwingConstants.CENTER);
        installPanel.setVisible(false);
        mainInput.add(installPanel);
        
        amountField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        totalField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        installField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
          
        input.add(mainInput);
        //frame.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        if (button.getText().equals("Clear"))
        {
            amountPanel.setVisible(false);
            totalPanel.setVisible(false);
            installPanel.setVisible(false);
            priceField.setText("0"); 
            paymentField.setText("0");
            rateField.setText("0");
            yearsField.setText("0");
            amountField.setText("0");
            totalField.setText("0");
            installField.setText("0");
        }
        else if (button.getText().equals("Calculate"))
        try {
            priceNum = Integer.parseInt(priceField.getText());
            paymentNum = Integer.parseInt(paymentField.getText());
            rateNum = Integer.parseInt(rateField.getText());
            yearsNum = Integer.parseInt(yearsField.getText());
                
            if (priceNum <= 0 || paymentNum <= 0 || rateNum < 0 || yearsNum < 0) {
                throw new IllegalArgumentException("Please enter valid values (greater than 0).");
            }
            if (paymentNum >= priceNum) {
                throw new IllegalArgumentException("Down payment shouldn't be more than the price.");
            }
            amountPanel.setVisible(true);
            totalPanel.setVisible(true);
            installPanel.setVisible(true);
            calculate();
            amountField.setText(String.valueOf((int)amountNum));
            totalField.setText(String.valueOf((int)totalNum));
            installField.setText(String.valueOf((int)installNum));
        
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values.");
            priceField.setText("0");
            paymentField.setText("0");
            rateField.setText("0");
            yearsField.setText("0");
            amountField.setText("0");
            totalField.setText("0");
            installField.setText("0");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            priceField.setText("0");
            paymentField.setText("0");
            rateField.setText("0");
            yearsField.setText("0");
            amountField.setText("0");
            totalField.setText("0");
            installField.setText("0");
        }
    }
    
    public void calculate(){
        amountNum = priceNum - paymentNum;
        totalNum = ((priceNum - paymentNum) + ((priceNum - paymentNum) * (rateNum / 100) * yearsNum));
        installNum = (((priceNum - paymentNum) + ((priceNum - paymentNum) * (rateNum / 100) * yearsNum)) / (yearsNum * 12));
    }
    
    /*public static void main(String[] args) {
            new Installment();
        }*/
    }