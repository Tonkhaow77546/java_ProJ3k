
package ConsultChat;


public class main {
    public static void main(String[] args) {
        ChatUser user = new ChatUser("localhost/my_chat","user",1,"guest001");
        
        user.updateDBChat("HELLO world");
        System.out.println(user.getRawLocalChat());
        user.autoUpdate();
    }
}
