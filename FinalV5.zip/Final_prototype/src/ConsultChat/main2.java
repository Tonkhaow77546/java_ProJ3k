
package ConsultChat;

public class main2 {
    
}
