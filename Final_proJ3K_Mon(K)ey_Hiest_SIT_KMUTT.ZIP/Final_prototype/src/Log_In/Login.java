package Log_In;

import Homepage.HomePage;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.border.Border;

public class Login extends JFrame {

    JLabel usernameLabel, passwordLabel;
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, createbutton;


    public Login() {
        
        
        
        setResizable(false);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        usernameLabel = new JLabel("Username:");
        Border bdr = BorderFactory.createLineBorder(Color.BLUE, 2, true);
        usernameLabel.setForeground(new Color(255, 255, 255));
        usernameLabel.setBackground(Color.GRAY);
        usernameLabel.setOpaque(true);
        usernameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(new Color(255, 255, 255));
        passwordLabel.setBackground(Color.GRAY);
        passwordLabel.setOpaque(true);
        passwordLabel.setForeground(new Color(255, 255, 255));
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        createbutton = new JButton("Create Account");
        createbutton.setFont(new Font("Segoe UI", Font.PLAIN, 20));

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = passwordField.getText();

                try {
                    Register register = new Register();
                    register.createTable();
                    Object[] UserInfo = register.Login(username, password);
                    if (UserInfo[0].equals(true)){
                        JOptionPane.showMessageDialog(Login.this, "Login successful!");
                        dispose();
                        try {
                            new HomePage((AccountDetail)UserInfo[1]);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (InstantiationException ex) {
                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(Login.this, "Invalid username or password.");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Login.this, "Error: " + ex.getMessage());
                }
            }
        });
        
        createbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new UserCreation();
            }
        });
        
        JPanel pane_l = new JPanel();
        pane_l.setLayout(new GridLayout(3,1));
        JPanel p1 = new JPanel();

        p1.setLayout(new FlowLayout());
        p1.setBackground(new Color(0,0,0, 0.0f));
        JPanel p2 = new JPanel();
        p2.setLayout(new FlowLayout());
        p2.setBackground(new Color(0,0,0, 0.0f));
        JPanel p3 = new JPanel();
        p3.setLayout(new FlowLayout());
        p3.setBackground(new Color(0,0,0, 0.0f));
        
        p1.add(usernameLabel);
        p1.add(usernameField);
        p2.add(passwordLabel);
        p2.add(passwordField);
        p3.add(loginButton);
        p3.add(createbutton);
        
        pane_l.add(p1);
        pane_l.add(p2);
        pane_l.add(p3);
        
        pane_l.setBackground(new Color(0,0,0, 0.0f));
        Image img = Toolkit.getDefaultToolkit().getImage("kmutt.jpg");
        try {

        JLabel lbl = new JLabel(new ImageIcon(ImageIO.read(new File("kmutt.jpg"))));
        this.setContentPane(lbl);
        lbl.setLayout(new FlowLayout());
        lbl.add(pane_l);
        } catch (IOException e) {};

        setSize(500,300);
        setLocationRelativeTo(null);

        

        
        //panel.setSize(300,300);

        //setContentPane(panel);
        
        //panel.locate(50, 50);
        
        setVisible(true);
    }

//    private Object[] isValidUser(Connection conn, String username, String password) throws SQLException {
//        String sql = "SELECT name, admin, id FROM Users WHERE username = ? AND password = ?";
//        PreparedStatement preparedStatement = conn.prepareStatement(sql);
//        preparedStatement.setString(1, username);
//        preparedStatement.setString(2, password);
//        ResultSet rs = preparedStatement.executeQuery();
//        if (rs.next()) {
//            String name = rs.getString("name");
//            boolean isAdmin = rs.getBoolean("admin");
//            int id = rs.getInt("id");
//            rs.close();
//            preparedStatement.close();
//            return new Object[]{true, name, isAdmin, id};
//        } else {
//            rs.close();
//            preparedStatement.close();
//            return new Object[]{false, null, null};
//        }
//    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Login();
            }
        });
    }
}
