/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Log_In;

/**
 *
 * @author Pattr
 */
public abstract class AccountBase {
    abstract boolean GetAdmin();
    abstract String GetName();
    abstract int GetId();
}