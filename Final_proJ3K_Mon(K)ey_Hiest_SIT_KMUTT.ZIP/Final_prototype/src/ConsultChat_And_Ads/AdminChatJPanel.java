package ConsultChat_And_Ads;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AdminChatJPanel extends JPanel{
    
}