//Formula calculated by https://www.set.or.th/th/education-research/education/happymoney/glossary/time-value-of-money?lang=th
package TimeValue.PresentValueHead;

import CustomException.MinusException;
import Homepage.Gframe;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class PresentValueUI implements ActionListener,Gframe{
    JPanel mainPanel, subPanel1, panelFrame;
    JPanel subButton, subResult;
    JLabel JFutureLabel, JRewardLabel, JTimeLabel, JResult1;
    JTextField JFutureText, JRewardResultText, JTimeText, JResult2;
    JButton JSummitButton, JResetButton;
   
    PresentValue presentValueFN;
    
    public PresentValueUI(){
        presentValueFN = new PresentValue();
        generateUI();
    }
    
    public void generateUI(){
        panelFrame = new JPanel(new BorderLayout());
        panelFrame.setSize(1920, 1080);
        
        mainPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        mainPanel.setSize(1920,1080);
        panelFrame.add(mainPanel, BorderLayout.CENTER);
        
        subPanel1 = new JPanel(new GridLayout(14, 1));
        mainPanel.add(subPanel1, BorderLayout.CENTER);
        
        //row1        
        JFutureLabel = new JLabel("Future Value (baht)", SwingConstants.LEFT);
        JFutureLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JFutureText = new JTextField("0");
        JFutureText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JFutureText.setPreferredSize(new Dimension(465,25));
        subPanel1.add(JFutureLabel);
        subPanel1.add(JFutureText);
        
        //row2
        JRewardLabel = new JLabel("Rate of Return (%)", SwingConstants.LEFT);
        JRewardLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JRewardResultText= new JTextField("0");
        JRewardResultText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subPanel1.add(JRewardLabel);
        subPanel1.add(JRewardResultText);
        
        //row3
        JTimeLabel = new JLabel("Period (year)", SwingConstants.LEFT);
        JTimeLabel.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JTimeText= new JTextField("0");
        JTimeText.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subPanel1.add(JTimeLabel);
        subPanel1.add(JTimeText);
        
        //button
        subButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JSummitButton = new JButton("Calculate");
        JResetButton = new JButton("Reset");
        JSummitButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JResetButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subButton.add(JSummitButton);
        subButton.add(JResetButton);
        subPanel1.add(new JPanel());
        subPanel1.add(subButton);
        subPanel1.add(new JPanel());
        
        //resultText
        subResult = new JPanel(new GridLayout(1,2));
        JResult1 = new  JLabel("Current sum is ");
        JResult1.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        subResult.add(JResult1);
        JResult2 = new JTextField("0");
        JResult2.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        JResult2.setEditable(false);
        JResult2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        subResult.add(JResult2);
        subPanel1.add(subResult);
        
        subResult.setVisible(false);
        
        JSummitButton.addActionListener(this);
        JResetButton.addActionListener(this);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        
        if(e.getSource().equals(JSummitButton)){
            try{
                if( Double.parseDouble(JFutureText.getText()) < 0 || Double.parseDouble(JRewardResultText.getText()) < 0 ||
                    Integer.parseInt(JTimeText.getText()) < 0){
                    throw new MinusException("You cannot enter negative numbers.");
                }
                FutureValSetValue();
                setEditAllTextField(false);
                JResult2.setText(String.valueOf((int)presentValueFN.calculate()));
                subResult.setVisible(true);
            }
            catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(null, "The information entered cannot be characters.","ERROR",  JOptionPane.ERROR_MESSAGE);
            }
            catch (MinusException ex) {
                JOptionPane.showMessageDialog(null, "You cannot enter negative numbers.","ERROR",  JOptionPane.ERROR_MESSAGE);
            }
        }
        
        
        if(e.getSource().equals(JResetButton)){
            textFieldAllSet("0");
            setEditAllTextField(true);
            subResult.setVisible(false);
        }
    }
    
    public void FutureValSetValue(){
        presentValueFN.setFutureVal(Double.parseDouble(JFutureText.getText()));
        presentValueFN.setReward(Double.parseDouble(JRewardResultText.getText()));
        presentValueFN.setTime(Integer.parseInt(JTimeText.getText()));
                  
    }
    
    public void textFieldAllSet(String data){
        JFutureText.setText(data);
        JRewardResultText.setText(data);
        JTimeText.setText(data);
        
    }
    
    public void setEditAllTextField(boolean data){
        JFutureText.setEditable(data);
        JRewardResultText.setEditable(data);
        JTimeText.setEditable(data);

        
    }
    
    public JPanel getFrame(){
        return panelFrame;
    }
    
//    public static void main(String[] args) {
//        new PresentValueUI();
//    }
    
    
}
