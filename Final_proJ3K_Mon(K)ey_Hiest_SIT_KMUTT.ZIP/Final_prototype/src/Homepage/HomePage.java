package Homepage;



import ConsultChat_And_Ads.AdsDownloaderPanel;
import ConsultChat_And_Ads.AdsUploaderPanel;
import ConsultChat_And_Ads.ChatJPanel;
import Expressed_plan.Account;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import java.awt.image.BufferedImage;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.Dimension;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import out_scource.RoundButton2;

import Taxes.Tax;
import retirement.RetireUI;
import TimeValue.TimevalueUI;
import Product_installments.InstallmentApp;
import installment.Installment;
import Provident_fund.Provident_fund;
import Expressed_plan.Main_screen;
import Credit_card.CreditCard;
import Log_In.AccountDetail;
import Money_loan.Compound;
import Money_loan.Fixed;
import short_saving.SaveMoneyUI;

/**
 *
 * @author TUF GAMING A15
 */
public class HomePage implements ActionListener {
    
    private JFrame frame_1;
    private JFrame frame_0;
    
    private JPanel panel_11;
    private JPanel panel_11_1;
    private JPanel panel_11_2;
    private JPanel panel_11_3;
    private JPanel panel_12;
    private JPanel panel_12_1;
    private JPanel panel_12_2;
    private JPanel panel_12_3;
    private JPanel panel_12_4;
    
    private JPanel panel_13;
    private JPanel panel_14;
    private ImageIcon icon_12_1;
        
    private JButton btn_12_1;
    private JButton btn_12_2;
    private JButton btn_12_3;
    private JButton btn_12_4;
    private JButton btn_12_5;
    private JButton btn_12_6;
    private JButton btn_12_7;
    private JButton btn_12_8;
    private JButton btn_12_9;
    private JButton btn_12_10;
    private JButton btn_12_11;
    private JButton btn_12_12;
    private JButton btn_12_13;
    
    private JButton btn_11_1;
    private JButton btn_11_2;
    
    private RoundButton2 rbtn_1;
    private RoundButton2 rbtn_2;
    private RoundButton2 rbtn_3;
    
    private JInternalFrame iframe_1;
    private JDesktopPane desktopPane;
    private AccountDetail userAccount;
    
    
    
    private final JPanel tax_panel = this.setFrame(new Tax());
    private final JPanel shorterm_panel = this.setFrame(new SaveMoneyUI());
    private final JPanel retired_panel = this.setFrame( new RetireUI());
    private final JPanel timevalue_panel = this.setFrame( new TimevalueUI()) ;
    private final JPanel product_install_panel = this.setFrame(new InstallmentApp()) ;
    private final JPanel Installment_panel = this.setFrame( new Installment());
    private final JPanel Provident_panel = this.setFrame( new Provident_fund());
    private JPanel Finance_rec_panel = null;//new Main_screen(new Account(true, "kk", 1)).getFrame(); 
    private final JPanel Fixed_loan = this.setFrame((new Fixed()));
    private final JPanel credit_panel = this.setFrame( new CreditCard());
    private final JPanel Compound_panel = this.setFrame(new Compound());
    
    private boolean profile_on = true; 
    private boolean menu_on = true; 
    private boolean action_point = true;
    
    
    public JPanel setFrame(Gframe e){
        return e.getFrame();
    }
    
    public HomePage(AccountDetail user) throws ClassNotFoundException, InstantiationException{
        this.userAccount = user;
        Finance_rec_panel = this.setFrame(new Main_screen(user));
        setLookAndField();
        frame_1 = new JFrame("Main");

        panel_11 = new JPanel();
        panel_11.setLayout(new BorderLayout());
        panel_11.setBackground(Color.GRAY);
        panel_11.setBorder(BorderFactory.createLineBorder(Color.GRAY,5));
        
        panel_11_1 = new JPanel();
        panel_11_1.setLayout(new GridLayout(1,1));
        panel_11_1.setBackground(Color.GRAY);
        btn_11_1 = new JButton("Home");
        btn_11_1.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        panel_11.add(panel_11_1,BorderLayout.WEST);
       
        
        panel_11_3 = new JPanel();
        panel_11_3.setLayout(new FlowLayout());
        panel_11_3.setBackground(Color.GRAY);
        
        
        rbtn_3 = new RoundButton2(" MENU ");
        panel_11_3.add(rbtn_3);
        rbtn_3.addActionListener(this);



        rbtn_2 = new RoundButton2("ProFile");
        panel_11_3.add(rbtn_2);
        rbtn_2.addActionListener(this);
        
        
        panel_11.add(panel_11_3,BorderLayout.EAST);
        
        panel_12 = new JPanel();
        panel_12.setLayout(new GridLayout(13,1,5,5));
        panel_12.setBackground(Color.lightGray);
        
        btn_12_1 = new JButton("Tax Calculation");

        btn_12_1.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_1);
        btn_12_1.addActionListener(this);
        
        btn_12_2 = new JButton("Short-Term Saving Plan");
        btn_12_2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_2);
        btn_12_2.addActionListener(this);
        
        btn_12_3 = new JButton("Retirement Saving Plan");
        btn_12_3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_3);
        btn_12_3.addActionListener(this);
        
        btn_12_4 = new JButton("Installment Plan");
        btn_12_4.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_4);
        btn_12_4.addActionListener(this);
        
        btn_12_5 = new JButton("Fixed Loan Plan");
        btn_12_5.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_5);
        btn_12_5.addActionListener(this);
        
        btn_12_6 = new JButton("Credit Card Plan");
        btn_12_6.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_6);
        btn_12_6.addActionListener(this);
        
        btn_12_7 = new JButton("Value by Time Calculation");
        btn_12_7.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_7);
        btn_12_7.addActionListener(this);
        
        btn_12_8 = new JButton("product intallment plan");
        btn_12_8.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_8);
        btn_12_8.addActionListener(this);
        
        btn_12_9 = new JButton("Provident Fund Plan");
        btn_12_9.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_9);
        btn_12_9.addActionListener(this);
        
        btn_12_10 = new JButton("Expressed Plan");
        btn_12_10.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_10);
        btn_12_10.addActionListener(this);
        
        btn_12_11 = new JButton("Expert-Chat");
        btn_12_11.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_11);
        btn_12_11.addActionListener(this);

        btn_12_12 = new JButton("Compound Loan Plan");
        btn_12_12.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        panel_12.add(btn_12_12);
        btn_12_12.addActionListener(this);
        
        btn_12_13 = new JButton("Admin Only");
        btn_12_13.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        if(user.GetAdmin()){
            panel_12.add(btn_12_13);
            btn_12_13.addActionListener(this);
        }

        panel_12.setBorder(BorderFactory.createLineBorder(Color.lightGray,5));
        panel_13 = new JPanel();
        panel_13.setLayout(new BorderLayout());
        panel_13.setBorder(BorderFactory.createLineBorder(Color.lightGray, 5));
        JPanel adspanel = new JPanel();
        adspanel.setLayout(new GridLayout(1, 1));
        adspanel.add(new AdsDownloaderPanel("localhost", "ads_db", "ads_storage", "root", ""));
        panel_13.add(adspanel, BorderLayout.CENTER);
        desktopPane = new JDesktopPane();
        iframe_1 = new JInternalFrame("User Detail", false, false, false,false);
        iframe_1.setLayout(new GridLayout(8,1));
        JTextField itxt_1 = new JTextField();
        
        JLabel ilabe_l = new JLabel("Lock In As:");
        ilabe_l.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        //ilabe_l.setHorizontalAlignment(SwingConstants.CENTER);
        
        itxt_1.setText(user.GetName());
        itxt_1.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        //itxt_1.setHorizontalAlignment(SwingConstants.CENTER);
        itxt_1.setEditable(false);
        JPanel ipanel_1 = new JPanel();
        ipanel_1.setLayout(new FlowLayout());
        ipanel_1.add(ilabe_l);
        ipanel_1.add(itxt_1);
        
        iframe_1.add(new JButton(new ImageIcon("src/Img/avatar280.png")));
        iframe_1.add(ipanel_1);


        
        
        
        frame_1.setLayout(new BorderLayout());
        
        frame_1.add(panel_11,BorderLayout.NORTH);
        frame_1.add(panel_12,BorderLayout.WEST);
        frame_1.add(panel_13,BorderLayout.CENTER);
        frame_1.add(iframe_1,BorderLayout.EAST);iframe_1.setVisible(true);
        frame_1.setSize(1920,1020);
        frame_1.setVisible(true);
        frame_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

    }
    public void playSound(String soundName){
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundName).getAbsoluteFile());
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex){
          System.out.println("Error with playing sound.");
          ex.printStackTrace( );
        }
    }  

    public void setLookAndField() throws ClassNotFoundException, InstantiationException{
        try{
            //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");

            //UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
            UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel");
            //UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
        }
        catch(Exception e){
            e.printStackTrace();
        } 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object sc = e.getSource();
        playSound("mixkit-cool-interface-click-tone-2568.wav");
        //profile button 
        if(sc.equals(rbtn_2)){
            if(profile_on == true){
                profile_on = false;
                frame_1.remove(iframe_1);
                frame_1.setVisible(true);
            }
            else{
                frame_1.add(iframe_1,BorderLayout.EAST);
                profile_on = true;
                frame_1.setVisible(true);
            }
        }

        //menu button 
        else if(sc.equals(rbtn_3)){
            
            if(menu_on == true){
                menu_on = false;
                frame_1.remove(panel_12);
                frame_1.setVisible(true);
            }
            else{
                frame_1.add(panel_12,BorderLayout.WEST);
                menu_on = true;
                frame_1.setVisible(true);
            }
        }
        //Backward button
        else if(sc.equals(btn_11_1)){
            btn_11_1.removeActionListener(this);
            panel_11_1.remove(btn_11_1);
            frame_1.remove(panel_13);
            panel_13 = new JPanel(); // Create a new panel
            panel_13.setLayout(new BorderLayout());
            panel_13.setBorder(BorderFactory.createLineBorder(Color.lightGray, 5));
            JPanel adspanel = new JPanel();
            adspanel.add(new AdsDownloaderPanel("localhost", "ads_db", "ads_storage", "root", ""));
            panel_13.add(adspanel, BorderLayout.CENTER);
            frame_1.add(panel_13, BorderLayout.CENTER);
            frame_1.revalidate();
            frame_1.repaint();
            } 
        //=============================================================================================================
        //taxes
        else if(sc.equals(btn_12_1)){
                if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
                frame_1.remove(panel_13);
                panel_13.setVisible(false);
                
                panel_13 = new JPanel();
                panel_13.setLayout(new BorderLayout());

                JLabel tmp1 = new JLabel("Taxes Calculation");
                tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
                tmp1.setHorizontalAlignment(JLabel.CENTER);

                panel_13.add(tmp1, BorderLayout.NORTH);
                panel_13.add(tax_panel, BorderLayout.CENTER);

                frame_1.add(panel_13, BorderLayout.CENTER);

                panel_13.setVisible(true);
                frame_1.setVisible(true);
                            }
        
        //shorterm
        else if(sc.equals(btn_12_2)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
                JLabel tmp1 = new JLabel("Short Term Saving Plan");
                tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
                tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(shorterm_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
            }
        
        //Retirement
        else if(sc.equals(btn_12_3)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
                JLabel tmp1 = new JLabel("Retirement Saving Plan");
                tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
                tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(retired_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //Installment plan
        else if(sc.equals(btn_12_4)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
           panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
                JLabel tmp1 = new JLabel("Installment Plan");
                tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
                tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(Installment_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //Fixed Loan Plan
        else if(sc.equals(btn_12_5)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
                JLabel tmp1 = new JLabel("Fixed Loan Plan");
                tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
                tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(Fixed_loan,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }

        //Credit Cards plan
        else if(sc.equals(btn_12_6)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
                JLabel tmp1 = new JLabel("Credit Cards plan");
                tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
                tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(credit_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
                
        //Value by time 
        else if(sc.equals(btn_12_7)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
            JLabel tmp1 = new JLabel("Value By Time Calculation");
            tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
            tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(timevalue_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //product installment 
        else if(sc.equals(btn_12_8)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
            JLabel tmp1 = new JLabel("Product Installment ");
            tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
            tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(product_install_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //Provident_panel
        else if(sc.equals(btn_12_9)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
            JLabel tmp1 = new JLabel("Provident Fund Plan");
            tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
            tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(Provident_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //Expressed plan >> Finance_rec_panel
        else if(sc.equals(btn_12_10)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
            JLabel tmp1 = new JLabel("Expressed plan");
            tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
            tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(Finance_rec_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //Expert_chat
        else if(sc.equals(btn_12_11)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
            JLabel tmp1 = new JLabel("Expert Chat");
            tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
            tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(new ChatJPanel("localhost", "chat_db", "chat_room", "root", "", userAccount.GetId(), "User_"+userAccount.GetName()), BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
        }
        
        //Compound_panel
        else if(sc.equals(btn_12_12)){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new BorderLayout());
            JLabel tmp1 = new JLabel("Compound panel");
            tmp1.setFont(new Font("Segoe UI", Font.PLAIN, 50));
            tmp1.setHorizontalAlignment(JLabel.CENTER);
            panel_13.add(tmp1,BorderLayout.NORTH);
            panel_13.add(Compound_panel,BorderLayout.CENTER);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
            //frame_1.setSize(1920,1080);
        }
        
        //Admin panel
        else if (sc.equals(btn_12_13) && userAccount.GetAdmin()){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(2,1));
            
            panel_13.add(new AdsUploaderPanel("localhost", "ads_db", "ads_storage", "root", ""));
            JPanel adminPanel = new JPanel(new BorderLayout());
            adminPanel.add(new ChatJPanel("localhost", "chat_db", "chat_room", "root", "", 1, "Admin_"+userAccount.GetName() ), BorderLayout.CENTER);
            JTextField roomId = new JTextField(25);
            roomId.setActionCommand("CHANGEROOM");
            roomId.addActionListener(this);
            JPanel roomIdPanel = new JPanel(new FlowLayout());
            roomIdPanel.add(new JLabel("Fill you client's ID :"));
            roomIdPanel.add(roomId);
            adminPanel.add(roomIdPanel, BorderLayout.EAST);
            panel_13.add(adminPanel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
        }else if(e.getActionCommand().equals("CHANGEROOM")){
            if (!panel_11_1.isAncestorOf(btn_11_1)) {
                    panel_11_1.add(btn_11_1);
                    btn_11_1.addActionListener(this);
                }
            frame_1.remove(panel_13);
            panel_13.setVisible(false);
                
            panel_13 = new JPanel();
            panel_13.setLayout(new GridLayout(2,1));
            
            panel_13.add(new AdsUploaderPanel("localhost", "ads_db", "ads_storage", "root", ""));
            JPanel adminPanel = new JPanel(new BorderLayout());
            int newRoomId;
            try{
                newRoomId = Integer.parseInt(((JTextField)sc).getText());
            }catch(Exception exc){
                System.out.println("Use int bro");
                System.out.println(exc);
                ((JTextField)sc).setText("");
                newRoomId = 1;
            }
            adminPanel.add(new ChatJPanel("localhost", "chat_db", "chat_room", "root", "", newRoomId, "Admin_"+userAccount.GetName() ), BorderLayout.CENTER);
            JTextField roomId = new JTextField(25);
            roomId.setActionCommand("CHANGEROOM");
            roomId.addActionListener(this);
            JPanel roomIdPanel = new JPanel(new FlowLayout());
            roomIdPanel.add(new JLabel("Fill you client's ID :"));
            roomIdPanel.add(roomId);
            adminPanel.add(roomIdPanel, BorderLayout.EAST);
            panel_13.add(adminPanel);

            frame_1.add(panel_13,BorderLayout.CENTER);
 
            frame_1.setVisible(true);
        }
    }
}


